// DocumentLibraryColumnsWebPart.ts  v2
import * as React from "react";
import * as ReactDom from "react-dom";
import { Version } from "@microsoft/sp-core-library";
import { IPropertyPaneConfiguration, PropertyPaneTextField } from "@microsoft/sp-property-pane";
import { BaseClientSideWebPart } from "@microsoft/sp-webpart-base";
import DocumentLibraryColumns from "./components/DocumentLibraryColumns";

export interface IWebPartProps { siteUrl: string; }

export default class DocumentLibraryColumnsWebPart extends BaseClientSideWebPart<IWebPartProps> {
  public render(): void {
    const element = React.createElement(DocumentLibraryColumns, {
      context: this.context,
      siteUrl: this.properties.siteUrl || this.context.pageContext.web.absoluteUrl,
    });
    ReactDom.render(element, this.domElement);
  }

  protected onDispose(): void { ReactDom.unmountComponentAtNode(this.domElement); }

  protected get dataVersion(): Version { return Version.parse("2.0"); }

  protected getPropertyPaneConfiguration(): IPropertyPaneConfiguration {
    return {
      pages: [{
        header: { description: "Configure Document Library Search" },
        groups: [{
          groupName: "Settings",
          groupFields: [
            PropertyPaneTextField("siteUrl", {
              label: "Site URL (optional)",
              description: "Leave blank to use the current site.",
              placeholder: "https://tenant.sharepoint.com/sites/mysite"
            })
          ]
        }]
      }]
    };
  }
}
