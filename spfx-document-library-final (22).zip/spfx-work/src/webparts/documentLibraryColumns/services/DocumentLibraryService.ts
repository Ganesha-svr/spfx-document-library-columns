// DocumentLibraryService.ts  (v11 — Debug logging + threshold fix)

import { WebPartContext } from "@microsoft/sp-webpart-base";
import { SPHttpClient, SPHttpClientResponse, ISPHttpClientOptions } from "@microsoft/sp-http";
import { IDocumentItem, ILibraryInfo } from "../components/IDocumentItem";

const POST_OPTIONS: ISPHttpClientOptions = {
  headers: {
    "Accept": "application/json",
    "Content-Type": "application/json",
    "Prefer": "HonorNonIndexedQueriesWarningMayFailOnLargeList"
  }
};

const PAGE_SIZE   = 100;
const MAX_RESULTS = 200;
const MAX_PAGES   = 20;

const BUILTIN_FIELDS = [
  "ID", "FileLeafRef", "FileRef", "Title",
  "FileDirRef", "FSObjType", "Created", "Modified",
  "Editor", "File_x0020_Size", "ContentType", "Author",
  "HTML_x0020_File_x0020_Type"
];

const CUSTOM_FIELD_CANDIDATES: { [key: string]: string[] } = {
  productNo:   ["ProductNo", "Product_x0020_No", "ProductNumber", "Product_No"],
  brandNo:     ["BrandNo",   "Brand_x0020_No",   "BrandNumber",   "Brand_No"],
  description: ["Description0", "Description", "Description1", "Desc"]
};

export class DocumentLibraryService {
  private context: WebPartContext;
  private siteUrl: string;
  private siteOrigin: string;
  private fieldCache: { [lib: string]: { [key: string]: string } } = {};

  constructor(context: WebPartContext, siteUrl?: string) {
    this.context   = context;
    this.siteUrl   = (siteUrl || context.pageContext.web.absoluteUrl).replace(/\/$/, "");
    this.siteOrigin = this.siteUrl.match(/^https?:\/\/[^/]+/)?.[0] || "";
    console.log("[SPFx] Service init — siteUrl:", this.siteUrl);
  }

  private async _get(url: string): Promise<any> {
    console.log("[SPFx] GET:", url);
    const response: SPHttpClientResponse = await this.context.spHttpClient.get(
      url, SPHttpClient.configurations.v1
    );
    console.log("[SPFx] GET response status:", response.status);
    if (!response.ok) {
      const text = await response.text();
      console.error("[SPFx] GET error body:", text.substring(0, 300));
      throw new Error(`HTTP ${response.status}: ${text.substring(0, 200)}`);
    }
    const json = await response.json();
    console.log("[SPFx] GET response keys:", Object.keys(json));
    return json;
  }

  private async _post(url: string, body: string): Promise<any> {
    console.log("[SPFx] POST:", url);
    console.log("[SPFx] POST body:", body.substring(0, 300));
    const response = await this.context.spHttpClient.post(
      url, SPHttpClient.configurations.v1,
      { ...POST_OPTIONS, body }
    );
    console.log("[SPFx] POST response status:", response.status);
    if (!response.ok) {
      const err = await response.text();
      console.error("[SPFx] POST error body:", err.substring(0, 500));
      throw new Error(`HTTP ${response.status}: ${err.substring(0, 300)}`);
    }
    const json = await response.json();
    console.log("[SPFx] POST response keys:", Object.keys(json));
    return json;
  }

  private async _discoverFields(libraryTitle: string): Promise<{ [key: string]: string }> {
    if (this.fieldCache[libraryTitle]) {
      console.log("[SPFx] Fields from cache:", this.fieldCache[libraryTitle]);
      return this.fieldCache[libraryTitle];
    }
    const result: { [key: string]: string } = {};
    try {
      const url  =
        `${this.siteUrl}/_api/web/lists/getByTitle('${encodeURIComponent(libraryTitle)}')` +
        `/fields?$select=InternalName&$filter=Hidden eq false`;
      const data = await this._get(url);
      const names: string[] = (data?.value || data?.d?.results || [])
        .map((f: any) => f.InternalName as string);
      console.log("[SPFx] All field names:", names.join(", "));
      for (const key of Object.keys(CUSTOM_FIELD_CANDIDATES)) {
        const found = CUSTOM_FIELD_CANDIDATES[key].find(c =>
          names.some(n => n.toLowerCase() === c.toLowerCase())
        );
        if (found) {
          result[key] = names.find(n => n.toLowerCase() === found.toLowerCase()) || found;
          console.log(`[SPFx] Field mapped: ${key} → ${result[key]}`);
        } else {
          console.warn(`[SPFx] Field NOT FOUND: ${key} — tried:`, CUSTOM_FIELD_CANDIDATES[key]);
        }
      }
    } catch (e) {
      console.error("[SPFx] Field discovery failed:", e);
    }
    this.fieldCache[libraryTitle] = result;
    return result;
  }

  private _matchesSearch(item: IDocumentItem, searchText: string): boolean {
    if (!searchText || !searchText.trim()) return true;
    const q = searchText.trim().toLowerCase();
    return (
      item.fileName.toLowerCase().indexOf(q)    !== -1 ||
      item.title.toLowerCase().indexOf(q)       !== -1 ||
      item.productNo.toLowerCase().indexOf(q)   !== -1 ||
      item.brandNo.toLowerCase().indexOf(q)     !== -1 ||
      item.description.toLowerCase().indexOf(q) !== -1 ||
      item.folderPath.toLowerCase().indexOf(q)  !== -1
    );
  }

  public getThumbnailUrl(serverRelativeUrl: string, fileExt: string): string {
    if (!serverRelativeUrl) return "";
    const exts = ["png","jpg","jpeg","gif","bmp","webp","pdf","doc","docx","xls","xlsx","ppt","pptx"];
    if (exts.indexOf(fileExt.toLowerCase()) !== -1) {
      return `${this.siteOrigin}/_layouts/15/getpreview.ashx?path=${encodeURIComponent(serverRelativeUrl)}&resolution=0`;
    }
    return "";
  }

  public getFolderUrl(fileDirRef: string): string {
    return fileDirRef ? `${this.siteOrigin}${fileDirRef}` : "";
  }

  public async getAllDocumentLibraries(): Promise<ILibraryInfo[]> {
    const url =
      `${this.siteUrl}/_api/web/lists` +
      `?$filter=BaseType eq 1 and Hidden eq false and IsCatalog eq false` +
      `&$select=Id,Title,ItemCount,LastItemModifiedDate,DefaultViewUrl,Description` +
      `&$orderby=Title asc`;
    const data  = await this._get(url);
    const lists = data?.value || data?.d?.results || [];
    console.log("[SPFx] Libraries found:", lists.map((l: any) => l.Title));
    return lists.map((lib: any): ILibraryInfo => ({
      id:             lib.Id,
      title:          lib.Title,
      itemCount:      lib.ItemCount || 0,
      lastModified:   lib.LastItemModifiedDate,
      defaultViewUrl: lib.DefaultViewUrl || "",
      description:    lib.Description   || ""
    }));
  }

  public async searchItems(
    libraryTitle: string,
    searchText: string,
    brandFilter: string
  ): Promise<IDocumentItem[]> {
    console.log("[SPFx] searchItems called:", { libraryTitle, searchText, brandFilter });
    const fields    = await this._discoverFields(libraryTitle);
    console.log("[SPFx] Discovered fields:", fields);

    const allFields = [
      ...BUILTIN_FIELDS,
      ...(fields.productNo   ? [fields.productNo]   : []),
      ...(fields.brandNo     ? [fields.brandNo]     : []),
      ...(fields.description ? [fields.description] : [])
    ];
    console.log("[SPFx] CAML fields:", allFields);

    const viewFields = allFields.map(f => `<FieldRef Name="${f}"/>`).join("");
    const apiUrl     = `${this.siteUrl}/_api/web/lists/getByTitle('${encodeURIComponent(libraryTitle)}')/getItems`;

    const results:  IDocumentItem[] = [];
    let   position: string | null   = null;
    let   page      = 0;

    while (page < MAX_PAGES && results.length < MAX_RESULTS) {
      page++;
      console.log(`[SPFx] Fetching page ${page}, results so far: ${results.length}`);

      const camlQuery = `
        <View Scope="RecursiveAll">
          <ViewFields>${viewFields}</ViewFields>
          <Query>
            <OrderBy><FieldRef Name="Modified" Ascending="FALSE"/></OrderBy>
          </Query>
          <RowLimit Paged="TRUE">${PAGE_SIZE}</RowLimit>
        </View>`;

      const queryObj: any = { ViewXml: camlQuery };
      if (position) queryObj.ListItemCollectionPosition = position;

      const data     = await this._post(apiUrl, JSON.stringify({ query: queryObj }));
      const rawItems = data?.value || data?.d?.results || [];
      console.log(`[SPFx] Page ${page}: raw items returned = ${rawItems.length}`);

      if (rawItems.length > 0) {
        console.log("[SPFx] First item sample:", JSON.stringify(rawItems[0]).substring(0, 200));
      }

      const mapped = rawItems
        .map((item: any) => this._mapItem(item, libraryTitle, fields))
        .filter((item: IDocumentItem) => item.fileName !== "" || item.isDocumentSet);

      console.log(`[SPFx] Page ${page}: mapped items = ${mapped.length}`);

      const filtered = mapped.filter((item: IDocumentItem) => {
        const matchesText  = this._matchesSearch(item, searchText);
        const matchesBrand = !brandFilter || brandFilter === "All"
          ? true
          : item.brandNo.toLowerCase() === brandFilter.toLowerCase();
        return matchesText && matchesBrand;
      });

      console.log(`[SPFx] Page ${page}: filtered matches = ${filtered.length}`);
      results.push(...filtered);

      // Check for next page token
      const nextToken = data?.__next || data?.d?.__next ||
        data?.["odata.nextLink"] || null;
      console.log("[SPFx] Next page token:", nextToken ? "exists" : "none");

      if (!nextToken || rawItems.length < PAGE_SIZE) break;
      position = nextToken;
    }

    console.log("[SPFx] Final results count:", results.length);
    return results.slice(0, MAX_RESULTS);
  }

  public async getDocumentSetChildren(
    libraryTitle: string,
    documentSetServerRelativeUrl: string
  ): Promise<IDocumentItem[]> {
    try {
      const fields     = await this._discoverFields(libraryTitle);
      const allFields  = [
        ...BUILTIN_FIELDS,
        ...(fields.productNo   ? [fields.productNo]   : []),
        ...(fields.brandNo     ? [fields.brandNo]     : []),
        ...(fields.description ? [fields.description] : [])
      ];
      const viewFields = allFields.map(f => `<FieldRef Name="${f}"/>`).join("");
      const camlQuery  = `
        <View Scope="RecursiveAll">
          <ViewFields>${viewFields}</ViewFields>
          <Query><OrderBy><FieldRef Name="FileLeafRef" Ascending="TRUE"/></OrderBy></Query>
          <RowLimit>200</RowLimit>
        </View>`;
      const apiUrl = `${this.siteUrl}/_api/web/lists/getByTitle('${encodeURIComponent(libraryTitle)}')/getItems`;
      const data   = await this._post(apiUrl, JSON.stringify({
        query: { ViewXml: camlQuery, FolderServerRelativeUrl: documentSetServerRelativeUrl }
      }));
      return (data?.value || data?.d?.results || [])
        .map((item: any) => this._mapItem(item, libraryTitle, fields))
        .filter((item: IDocumentItem) => !item.isDocumentSet && item.fileName !== "");
    } catch (e) {
      console.error("[SPFx] getDocumentSetChildren:", e);
      return [];
    }
  }

  public async getBrandOptions(libraryTitle: string): Promise<string[]> {
    const fields = await this._discoverFields(libraryTitle);
    if (!fields.brandNo) return [];
    try {
      const url  =
        `${this.siteUrl}/_api/web/lists/getByTitle('${encodeURIComponent(libraryTitle)}')` +
        `/fields/getByInternalNameOrTitle('${fields.brandNo}')?$select=Choices,FieldTypeKind`;
      const data    = await this._get(url);
      const choices = data?.Choices?.results || data?.Choices ||
                      data?.d?.Choices?.results || data?.d?.Choices || [];
      if (choices.length > 0) return choices;
    } catch { /* fall through */ }
    try {
      const url  =
        `${this.siteUrl}/_api/web/lists/getByTitle('${encodeURIComponent(libraryTitle)}')` +
        `/items?$select=${fields.brandNo}&$top=200`;
      const data  = await this._get(url);
      const items = data?.value || data?.d?.results || [];
      const all   = items.map((i: any) => i[fields.brandNo]).filter((b: any) => b && b.toString().trim());
      return all.reduce((acc: string[], val: string) => {
        if (acc.indexOf(val) === -1) acc.push(val);
        return acc;
      }, []).sort();
    } catch { return []; }
  }

  private _mapItem(item: any, libraryTitle: string, fields: { [key: string]: string }): IDocumentItem {
    const fileLeafRef   = item["FileLeafRef"] || "";
    const fileDirRef    = item["FileDirRef"]  || "";
    const serverRelUrl  = item["FileRef"]     || "";
    const htmlFileType  = (item["HTML_x0020_File_x0020_Type"] || "").toLowerCase();
    const contentType   = item["ContentType"] || "";
    const isFolder      = item["FSObjType"] === 1 || item["FSObjType"] === "1";
    const isDocumentSet = isFolder && (
      contentType.toLowerCase().indexOf("document set") !== -1 ||
      htmlFileType.indexOf("sharepoint.documentset") !== -1
    );
    const folderPath    = this._extractFolderPath(fileDirRef, libraryTitle);
    const folderName    = fileDirRef.split("/").pop() || "";
    const folderUrl     = this.getFolderUrl(fileDirRef);
    const fileExt       = fileLeafRef.split(".").pop()?.toLowerCase() || "";
    const thumbnailUrl  = isFolder ? "" : this.getThumbnailUrl(serverRelUrl, fileExt);
    const documentSetUrl = isDocumentSet
      ? `${this.siteOrigin}${serverRelUrl}/Forms/default.aspx` : "";

    const getTitle = (f: any): string => {
      if (!f) return "";
      if (typeof f === "string") return f;
      if (f.Title) return f.Title;
      if (f.results && f.results[0]) return f.results[0].Title || "";
      return "";
    };

    return {
      id:                item["ID"]  || item["Id"] || 0,
      title:             item["Title"]             || "",
      name:              item["Title"]             || fileLeafRef || "(No Name)",
      productNo:         fields.productNo   ? (item[fields.productNo]   || "") : "",
      brandNo:           fields.brandNo     ? (item[fields.brandNo]     || "") : "",
      description:       fields.description ? (item[fields.description] || "") : "",
      fileName:          fileLeafRef,
      folderName,        folderPath,         folderUrl,
      fileRef:           serverRelUrl ? `${this.siteOrigin}${serverRelUrl}` : "",
      serverRelativeUrl: serverRelUrl,
      libraryTitle,
      created:           item["Created"]           || "",
      modified:          item["Modified"]          || "",
      modifiedBy:        getTitle(item["Editor"]),
      fileSize:          item["File_x0020_Size"]   || 0,
      isFolder,          isDocumentSet,             documentSetUrl,
      contentType,       thumbnailUrl
    };
  }

  private _extractFolderPath(fileDirRef: string, libraryTitle: string): string {
    if (!fileDirRef) return "";
    const parts    = fileDirRef.split("/");
    const libIndex = parts.findIndex(p =>
      p.toLowerCase() === libraryTitle.toLowerCase() ||
      decodeURIComponent(p).toLowerCase() === libraryTitle.toLowerCase()
    );
    if (libIndex === -1) return parts[parts.length - 1] || "";
    const sub = parts.slice(libIndex + 1).filter(Boolean);
    return sub.length > 0 ? sub.join(" / ") : "(Root)";
  }

  private _escapeXml(str: string): string {
    return str.replace(/&/g,"&amp;").replace(/</g,"&lt;").replace(/>/g,"&gt;")
              .replace(/"/g,"&quot;").replace(/'/g,"&apos;");
  }
}
