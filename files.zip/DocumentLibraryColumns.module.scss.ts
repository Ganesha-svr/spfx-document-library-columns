// DocumentLibraryColumns.module.scss.ts
// Auto-generated CSS Module type declarations.
// This file tells TypeScript what class names exist in the SCSS module.
// If you add a new class to the .scss file, add it here too.

declare const styles: {
  // Layout
  readonly wrap: string;

  // Header
  readonly header: string;
  readonly headerIcon: string;
  readonly headerTitle: string;
  readonly headerSub: string;

  // Search Panel
  readonly searchPanel: string;
  readonly fieldGroup: string;
  readonly fieldLabel: string;
  readonly labelIcon: string;
  readonly selectWrap: string;
  readonly select: string;
  readonly selectArrow: string;
  readonly searchRow: string;
  readonly searchInputWrap: string;
  readonly searchIcon: string;
  readonly searchInput: string;
  readonly clearBtn: string;

  // Filters
  readonly filterRow: string;
  readonly filterGroup: string;
  readonly filterLabel: string;
  readonly chips: string;
  readonly chip: string;
  readonly chipActive: string;
  readonly searchBtn: string;
  readonly spinner: string;
  readonly loadingPill: string;

  // Error / Loading
  readonly errorBar: string;
  readonly searching: string;
  readonly searchingDots: string;

  // Results
  readonly resultsSection: string;
  readonly resultsMeta: string;
  readonly resultsCount: string;
  readonly resultsIn: string;
  readonly recursiveBadge: string;
  readonly resultsList: string;

  // Result Card
  readonly resultCard: string;
  readonly resultCardExpanded: string;
  readonly cardMain: string;
  readonly cardEmoji: string;
  readonly cardBody: string;
  readonly cardTitleRow: string;
  readonly cardTitle: string;
  readonly cardMeta: string;
  readonly metaChip: string;
  readonly metaLabel: string;
  readonly cardActions: string;
  readonly openBtn: string;
  readonly expandBtn: string;
  readonly expandBtnOpen: string;

  // Status Badge
  readonly statusBadge: string;
  readonly statusDot: string;

  // Expanded Details
  readonly cardDetails: string;
  readonly detailsGrid: string;
  readonly detailItem: string;
  readonly detailItemWide: string;
  readonly detailLabel: string;
  readonly detailValue: string;
  readonly detailLink: string;
  readonly fileLink: string;

  // Folder Path Breadcrumb
  readonly folderPathInline: string;
  readonly folderBreadcrumb: string;
  readonly folderCrumb: string;
  readonly folderCrumbWrap: string;
  readonly folderSep: string;

  // Highlight
  readonly highlight: string;

  // Empty State
  readonly emptyState: string;
  readonly emptyIcon: string;
  readonly emptyTitle: string;
  readonly emptySub: string;
  readonly clearFiltersBtn: string;

  // Idle / Library Quick-pick
  readonly idleState: string;
  readonly idleGrid: string;
  readonly libraryCard: string;
  readonly libIcon: string;
  readonly libName: string;
  readonly libCount: string;
  readonly idleHint: string;
};

export default styles;
