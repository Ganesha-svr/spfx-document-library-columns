// DocumentLibraryColumnsWebPart.ts  v9 — no custom headers on GET
import * as React from "react";
import * as ReactDom from "react-dom";
import { Version } from "@microsoft/sp-core-library";
import { IPropertyPaneConfiguration, PropertyPaneTextField } from "@microsoft/sp-property-pane";
import { BaseClientSideWebPart } from "@microsoft/sp-webpart-base";
import { SPHttpClient, SPHttpClientResponse } from "@microsoft/sp-http";
import DocumentLibraryColumns from "./components/DocumentLibraryColumns";

export interface IWebPartProps { siteUrl: string; }

export default class DocumentLibraryColumnsWebPart extends BaseClientSideWebPart<IWebPartProps> {

  private async _runDiagnostics(): Promise<string | null> {
    try {
      const siteUrl  = (this.properties.siteUrl || this.context.pageContext.web.absoluteUrl).replace(/\/$/, "");
      const testUrl  = `${siteUrl}/_api/web?$select=Title`;
      // No custom headers — SPHttpClient.configurations.v1 sets correct headers automatically
      const response: SPHttpClientResponse = await this.context.spHttpClient.get(
        testUrl, SPHttpClient.configurations.v1
      );
      if (!response.ok) {
        const body = await response.text();
        return `HTTP ${response.status} — ${response.statusText}\n\nDetails: ${body.substring(0, 300)}`;
      }
      return null;
    } catch (e) {
      return `Connection error: ${e.message}`;
    }
  }

  public async render(): Promise<void> {
    const diagError = await this._runDiagnostics();

    if (diagError) {
      this.domElement.innerHTML = `
        <div style="font-family:'Segoe UI',sans-serif;padding:20px;background:#fff;border-radius:8px;border-left:5px solid #d13438;box-shadow:0 2px 8px rgba(0,0,0,0.1);max-width:700px;">
          <div style="font-size:20px;font-weight:700;color:#d13438;margin-bottom:12px;">⚠️ Connection Error</div>
          <pre style="background:#fef0f0;border:1px solid #f4c0c0;border-radius:6px;padding:12px;font-size:12px;color:#a4262c;white-space:pre-wrap;">${diagError}</pre>
          <div style="margin-top:16px;font-size:13px;color:#555;">
            <strong>Common causes:</strong><br/>
            &bull; <strong>401</strong> — Session expired. Refresh the page.<br/>
            &bull; <strong>403</strong> — No permission to this site.<br/>
            &bull; <strong>404</strong> — Site URL is wrong. Check web part properties.<br/>
          </div>
          <div style="margin-top:12px;padding:12px;background:#f0f8ff;border-radius:6px;font-size:12px;">
            <strong>Site URL:</strong> <code>${this.properties.siteUrl || this.context.pageContext.web.absoluteUrl}</code><br/>
            <strong>User:</strong> <code>${this.context.pageContext.user.loginName}</code>
          </div>
        </div>`;
      return;
    }

    const element = React.createElement(DocumentLibraryColumns, {
      context: this.context,
      siteUrl: this.properties.siteUrl || this.context.pageContext.web.absoluteUrl,
    });
    ReactDom.render(element, this.domElement);
  }

  protected onDispose(): void { ReactDom.unmountComponentAtNode(this.domElement); }
  protected get dataVersion(): Version { return Version.parse("2.0"); }

  protected getPropertyPaneConfiguration(): IPropertyPaneConfiguration {
    return {
      pages: [{
        header: { description: "Configure Document Library Search" },
        groups: [{
          groupName: "Settings",
          groupFields: [
            PropertyPaneTextField("siteUrl", {
              label: "Site URL (optional)",
              description: "Leave blank to use the current site.",
              placeholder: "https://tenant.sharepoint.com/sites/mysite"
            })
          ]
        }]
      }]
    };
  }
}
