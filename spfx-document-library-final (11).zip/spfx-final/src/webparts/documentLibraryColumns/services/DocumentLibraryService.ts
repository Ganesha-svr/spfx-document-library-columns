// DocumentLibraryService.ts  (v7 — Uses fetch() directly, bypasses SPHttpClient 406 issue)
// Root cause of 406: SPHttpClient.configurations.v1 injects its own Accept header
// which some SharePoint Communication Site tenants reject.
// Fix: Use native fetch() with explicit digest token for POST, bearer token for GET.

import { WebPartContext } from "@microsoft/sp-webpart-base";
import { IDocumentItem, ILibraryInfo } from "../components/IDocumentItem";

export class DocumentLibraryService {
  private context: WebPartContext;
  private siteUrl: string;

  private readonly CAML_FIELDS = [
    "ID", "FileLeafRef", "FileRef", "Title",
    "ProductNo", "BrandNo", "Description0",
    "FileDirRef", "FSObjType", "Created", "Modified",
    "Editor", "File_x0020_Size", "ContentType", "Author"
  ];

  constructor(context: WebPartContext, siteUrl?: string) {
    this.context = context;
    this.siteUrl = (siteUrl || context.pageContext.web.absoluteUrl).replace(/\/$/, "");
  }

  // ─── Get request digest for POST requests ────────────────────────────────
  private async _getDigest(): Promise<string> {
    try {
      const r = await fetch(`${this.siteUrl}/_api/contextinfo`, {
        method: "POST",
        credentials: "same-origin",
        headers: {
          "Accept": "application/json;odata=verbose",
          "Content-Type": "application/json;odata=verbose"
        }
      });
      const d = await r.json();
      return d?.d?.GetContextWebInformation?.FormDigestValue || "";
    } catch {
      return "";
    }
  }

  // ─── Generic GET helper ───────────────────────────────────────────────────
  private async _get(url: string): Promise<any> {
    const r = await fetch(url, {
      method: "GET",
      credentials: "same-origin",
      headers: {
        "Accept": "application/json;odata=verbose",
        "Content-Type": "application/json;odata=verbose"
      }
    });
    if (!r.ok) {
      const txt = await r.text();
      throw new Error(`HTTP ${r.status} — ${txt.substring(0, 300)}`);
    }
    return r.json();
  }

  // ─── Generic POST helper ──────────────────────────────────────────────────
  private async _post(url: string, body: string): Promise<any> {
    const digest = await this._getDigest();
    const r = await fetch(url, {
      method: "POST",
      credentials: "same-origin",
      headers: {
        "Accept": "application/json;odata=verbose",
        "Content-Type": "application/json;odata=verbose",
        "X-RequestDigest": digest,
        "Prefer": "HonorNonIndexedQueriesWarningMayFailOnLargeList"
      },
      body
    });
    if (!r.ok) {
      const txt = await r.text();
      throw new Error(`HTTP ${r.status} — ${txt.substring(0, 300)}`);
    }
    return r.json();
  }

  // ─── List all Document Libraries ─────────────────────────────────────────
  public async getAllDocumentLibraries(): Promise<ILibraryInfo[]> {
    try {
      const url =
        `${this.siteUrl}/_api/web/lists` +
        `?$filter=BaseType eq 1 and Hidden eq false and IsCatalog eq false` +
        `&$select=Id,Title,ItemCount,LastItemModifiedDate,DefaultViewUrl,Description` +
        `&$orderby=Title asc`;

      const data  = await this._get(url);
      const lists: any[] = data?.d?.results || [];

      return lists.map((lib: any): ILibraryInfo => ({
        id:             lib.Id,
        title:          lib.Title,
        itemCount:      lib.ItemCount || 0,
        lastModified:   lib.LastItemModifiedDate,
        defaultViewUrl: lib.DefaultViewUrl || "",
        description:    lib.Description   || ""
      }));
    } catch (error) {
      console.error("[Service] getAllDocumentLibraries:", error);
      throw error;
    }
  }

  // ─── Search Items — CAML RecursiveAll ────────────────────────────────────
  public async searchItems(
    libraryTitle: string,
    searchText: string,
    brandFilter: string
  ): Promise<IDocumentItem[]> {
    try {
      const whereClause = this._buildWhereClause(searchText, brandFilter);
      const viewFields  = this.CAML_FIELDS.map(f => `<FieldRef Name="${f}"/>`).join("");

      const camlQuery = `
        <View Scope="RecursiveAll">
          <ViewFields>${viewFields}</ViewFields>
          <Query>
            <OrderBy><FieldRef Name="Modified" Ascending="FALSE"/></OrderBy>
            ${whereClause ? `<Where>${whereClause}</Where>` : ""}
          </Query>
          <RowLimit Paged="TRUE">500</RowLimit>
        </View>`;

      const url  = `${this.siteUrl}/_api/web/lists/getByTitle('${encodeURIComponent(libraryTitle)}')/getItems`;
      const body = JSON.stringify({
        query: {
          __metadata: { type: "SP.CamlQuery" },
          ViewXml: camlQuery
        }
      });

      const data     = await this._post(url, body);
      const rawItems: any[] = data?.d?.results || [];

      return rawItems
        .map(item  => this._mapToDocumentItem(item, libraryTitle))
        .filter(item => item.fileName !== "");

    } catch (error) {
      console.error("[Service] searchItems:", error);
      throw error;
    }
  }

  // ─── Get Brand No options ─────────────────────────────────────────────────
  public async getBrandOptions(libraryTitle: string): Promise<string[]> {
    try {
      const url =
        `${this.siteUrl}/_api/web/lists/getByTitle('${encodeURIComponent(libraryTitle)}')` +
        `/fields/getByInternalNameOrTitle('BrandNo')?$select=Choices,FieldTypeKind`;

      const d       = await this._get(url);
      const choices = d?.d?.Choices?.results || d?.d?.Choices || [];
      if (choices.length > 0) return choices;
    } catch { /* fall through */ }

    try {
      const url =
        `${this.siteUrl}/_api/web/lists/getByTitle('${encodeURIComponent(libraryTitle)}')` +
        `/items?$select=BrandNo&$top=200`;

      const d     = await this._get(url);
      const items: any[] = d?.d?.results || [];

      const allBrands: string[] = items
        .map((i: any) => i.BrandNo)
        .filter((b: any) => b && b.toString().trim() !== "");

      return allBrands.reduce((acc: string[], val: string) => {
        if (acc.indexOf(val) === -1) acc.push(val);
        return acc;
      }, []).sort();
    } catch {
      return [];
    }
  }

  // ─── Private: CAML Where clause ──────────────────────────────────────────
  private _buildWhereClause(searchText: string, brandFilter: string): string {
    const conditions: string[] = [];

    if (searchText && searchText.trim()) {
      const q = this._escapeXml(searchText.trim());
      conditions.push(`
        <Or>
          <Or>
            <Or>
              <Or>
                <Contains><FieldRef Name="FileLeafRef"/><Value Type="Text">${q}</Value></Contains>
                <Contains><FieldRef Name="Title"/><Value Type="Text">${q}</Value></Contains>
              </Or>
              <Contains><FieldRef Name="ProductNo"/><Value Type="Text">${q}</Value></Contains>
            </Or>
            <Contains><FieldRef Name="BrandNo"/><Value Type="Text">${q}</Value></Contains>
          </Or>
          <Contains><FieldRef Name="Description0"/><Value Type="Text">${q}</Value></Contains>
        </Or>`);
    }

    if (brandFilter && brandFilter !== "All") {
      conditions.push(`
        <Eq>
          <FieldRef Name="BrandNo"/>
          <Value Type="Text">${this._escapeXml(brandFilter)}</Value>
        </Eq>`);
    }

    if (conditions.length === 0) return "";
    if (conditions.length === 1) return conditions[0];
    return conditions.reduce((acc, cond) => acc ? `<And>${acc}${cond}</And>` : cond);
  }

  // ─── Private: Map raw item → IDocumentItem ───────────────────────────────
  private _mapToDocumentItem(item: any, libraryTitle: string): IDocumentItem {
    const fileLeafRef: string = item["FileLeafRef"] || "";
    const fileDirRef:  string = item["FileDirRef"]  || "";
    const isFolder = item["FSObjType"] === 1 || item["FSObjType"] === "1";
    const folderPath  = this._extractFolderPath(fileDirRef, libraryTitle);
    const folderName  = fileDirRef.split("/").pop() || "";
    const siteOrigin  = this.siteUrl.match(/^https?:\/\/[^/]+/)?.[0] || "";
    const fileRef     = item["FileRef"] ? `${siteOrigin}${item["FileRef"]}` : "";

    const getTitle = (f: any): string => {
      if (!f) return "";
      if (typeof f === "string") return f;
      if (f.Title) return f.Title;
      if (f.results && f.results[0]?.Title) return f.results[0].Title;
      return "";
    };

    return {
      id:          item["ID"]   || item["Id"] || 0,
      title:       item["Title"]        || "",
      name:        item["Title"]        || fileLeafRef || "(No Name)",
      productNo:   item["ProductNo"]    || "",
      brandNo:     item["BrandNo"]      || "",
      description: item["Description0"] || item["Description"] || "",
      fileName:    fileLeafRef,
      folderName,  folderPath, fileRef,
      serverRelativeUrl: item["FileRef"] || "",
      libraryTitle,
      created:    item["Created"]  || "",
      modified:   item["Modified"] || "",
      modifiedBy: getTitle(item["Editor"]),
      fileSize:   item["File_x0020_Size"] || 0,
      isFolder,
      contentType: item["ContentType"] || ""
    };
  }

  // ─── Private: Folder path ────────────────────────────────────────────────
  private _extractFolderPath(fileDirRef: string, libraryTitle: string): string {
    if (!fileDirRef) return "";
    const parts    = fileDirRef.split("/");
    const libIndex = parts.findIndex(
      p => p.toLowerCase() === libraryTitle.toLowerCase() ||
           decodeURIComponent(p).toLowerCase() === libraryTitle.toLowerCase()
    );
    if (libIndex === -1) return parts[parts.length - 1] || "";
    const subParts = parts.slice(libIndex + 1).filter(Boolean);
    return subParts.length > 0 ? subParts.join(" / ") : "(Root)";
  }

  // ─── Private: Escape XML ─────────────────────────────────────────────────
  private _escapeXml(str: string): string {
    return str
      .replace(/&/g, "&amp;").replace(/</g, "&lt;")
      .replace(/>/g, "&gt;").replace(/"/g, "&quot;")
      .replace(/'/g, "&apos;");
  }
}
