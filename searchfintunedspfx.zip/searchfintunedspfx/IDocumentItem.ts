export interface IDocumentItem {
  id: number;
  // ── Your document library columns ────────────────────────────────────────
  title: string;            // Title column
  name: string;             // Name column (display name / item name)
  productNo: string;        // Product No  (internal name: ProductNo)
  brandNo: string;          // Brand No    (internal name: BrandNo)
  description: string;      // Description (internal name: Description0 or Description)
  fileName: string;         // Actual filename with extension (FileLeafRef)
  // ── System / navigation fields ───────────────────────────────────────────
  folderName: string;       // Immediate parent folder (leaf of FileDirRef)
  folderPath: string;       // Full nested path e.g. "Folder1 / Sub / Deep"
  fileRef: string;          // Absolute URL to open file
  serverRelativeUrl: string;
  libraryTitle: string;
  created: string;
  modified: string;
  modifiedBy: string;
  fileSize: number;
  isFolder: boolean;
  contentType: string;
}

export interface ILibraryInfo {
  id: string;
  title: string;
  itemCount: number;
  lastModified: string;
  defaultViewUrl: string;
  description: string;
}

export interface ISearchState {
  libraries: ILibraryInfo[];
  selectedLibrary: string;
  searchText: string;
  brandFilter: string;      // filter by Brand No
  results: IDocumentItem[];
  isLoadingLibraries: boolean;
  isSearching: boolean;
  hasSearched: boolean;
  errorMessage: string;
  brandOptions: string[];
  expandedItemId: number | null;
}
