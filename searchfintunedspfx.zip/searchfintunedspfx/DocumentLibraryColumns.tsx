// DocumentLibraryColumns.tsx  v4 — Product Library Columns
// Columns: Title, Name, Product No, Brand No, Description, FileName
import * as React from "react";
import { DocumentLibraryService } from "../services/DocumentLibraryService";
import { IDocumentItem, ILibraryInfo, ISearchState } from "./IDocumentItem";
import styles from "./DocumentLibraryColumns.module.scss";

interface Props { context: any; siteUrl?: string; }

const FILE_ICONS: Record<string, string> = {
  pdf: "📄", doc: "📝", docx: "📝", xls: "📊", xlsx: "📊",
  ppt: "📋", pptx: "📋", txt: "📃", png: "🖼️", jpg: "🖼️",
  jpeg: "🖼️", gif: "🖼️", zip: "🗜️", msg: "✉️", mp4: "🎬", folder: "📁"
};

function getFileEmoji(item: IDocumentItem): string {
  if (item.isFolder) return FILE_ICONS.folder;
  const ext = item.fileName?.split(".").pop()?.toLowerCase() || "";
  return FILE_ICONS[ext] || "📄";
}

function formatSize(bytes: number): string {
  if (!bytes) return "";
  if (bytes < 1024) return `${bytes} B`;
  if (bytes < 1024 * 1024) return `${(bytes / 1024).toFixed(1)} KB`;
  return `${(bytes / (1024 * 1024)).toFixed(1)} MB`;
}

function formatDate(dateStr: string): string {
  if (!dateStr) return "";
  return new Date(dateStr).toLocaleDateString("en-GB", { day: "2-digit", month: "short", year: "numeric" });
}

function highlight(text: string, query: string): React.ReactNode {
  if (!query || !text) return text || "";
  const safe = query.replace(/[.*+?^${}()|[\]\\]/g, "\\$&");
  const regex = new RegExp(`(${safe})`, "gi");
  return text.split(regex).map((part, i) =>
    regex.test(part) ? <mark key={i} className={styles.highlight}>{part}</mark> : part
  );
}

export default class DocumentLibraryColumns extends React.Component<Props, ISearchState> {
  private service: DocumentLibraryService;
  private searchDebounce: any = null;

  constructor(props: Props) {
    super(props);
    this.service = new DocumentLibraryService(props.context, props.siteUrl);
    this.state = {
      libraries: [], selectedLibrary: "",
      searchText: "", brandFilter: "All",
      results: [], isLoadingLibraries: true,
      isSearching: false, hasSearched: false,
      errorMessage: "", brandOptions: [], expandedItemId: null
    };
  }

  public async componentDidMount(): Promise<void> {
    this.setState({ isLoadingLibraries: true });
    try {
      const libraries = await this.service.getAllDocumentLibraries();
      this.setState({ libraries, isLoadingLibraries: false });
    } catch (e) {
      this.setState({ isLoadingLibraries: false, errorMessage: "Could not load libraries: " + e.message });
    }
  }

  private async _onLibraryChange(title: string): Promise<void> {
    this.setState({ selectedLibrary: title, brandOptions: [], results: [], hasSearched: false, errorMessage: "" });
    if (!title) return;
    const brands = await this.service.getBrandOptions(title);
    this.setState({ brandOptions: brands });
  }

  private _onSearchInput(val: string): void {
    this.setState({ searchText: val });
    if (this.searchDebounce) clearTimeout(this.searchDebounce);
    if (val.trim().length >= 2) {
      this.searchDebounce = setTimeout(() => this._doSearch(), 400);
    }
  }

  private async _doSearch(): Promise<void> {
    const { selectedLibrary, searchText, brandFilter } = this.state;
    if (!selectedLibrary) { this.setState({ errorMessage: "Please select a document library first." }); return; }
    this.setState({ isSearching: true, errorMessage: "", hasSearched: false });
    try {
      const results = await this.service.searchItems(selectedLibrary, searchText, brandFilter);
      this.setState({ results, isSearching: false, hasSearched: true });
    } catch (e) {
      this.setState({ isSearching: false, errorMessage: "Search failed: " + e.message, hasSearched: true, results: [] });
    }
  }

  private _onClear(): void {
    if (this.searchDebounce) clearTimeout(this.searchDebounce);
    this.setState({ searchText: "", brandFilter: "All", results: [], hasSearched: false, errorMessage: "", expandedItemId: null });
  }

  private _toggleExpand(id: number): void {
    this.setState(prev => ({ expandedItemId: prev.expandedItemId === id ? null : id }));
  }

  public render(): JSX.Element {
    const {
      libraries, selectedLibrary, searchText, brandFilter,
      results, isLoadingLibraries, isSearching, hasSearched,
      errorMessage, brandOptions, expandedItemId
    } = this.state;

    const hasFilters = !!(searchText || brandFilter !== "All");

    return (
      <div className={styles.wrap}>

        {/* ── Header ─────────────────────────────────────────────────────── */}
        <div className={styles.header}>
          <div className={styles.headerIcon}>📦</div>
          <div>
            <div className={styles.headerTitle}>Product Document Search</div>
            <div className={styles.headerSub}>Search by Title, Name, Product No, Brand No or Description — across all folders</div>
          </div>
        </div>

        {/* ── Search Panel ────────────────────────────────────────────────── */}
        <div className={styles.searchPanel}>

          {/* Library picker */}
          <div className={styles.fieldGroup}>
            <label className={styles.fieldLabel}>
              <span className={styles.labelIcon}>📚</span> Document Library
            </label>
            {isLoadingLibraries ? (
              <div className={styles.loadingPill}>⟳ Loading libraries…</div>
            ) : (
              <div className={styles.selectWrap}>
                <select
                  className={styles.select}
                  value={selectedLibrary}
                  onChange={e => this._onLibraryChange(e.target.value)}
                >
                  <option value="">— Choose a library —</option>
                  {libraries.map(lib => (
                    <option key={lib.id} value={lib.title}>
                      {lib.title} ({lib.itemCount} items)
                    </option>
                  ))}
                </select>
                <span className={styles.selectArrow}>▾</span>
              </div>
            )}
          </div>

          {/* Search input */}
          <div className={styles.searchRow}>
            <div className={styles.searchInputWrap}>
              <span className={styles.searchIcon}>🔍</span>
              <input
                className={styles.searchInput}
                type="text"
                placeholder="Search by Title, Name, Product No, Brand No, Description…"
                value={searchText}
                onChange={e => this._onSearchInput(e.target.value)}
                onKeyDown={e => e.key === "Enter" && this._doSearch()}
                disabled={!selectedLibrary}
              />
              {hasFilters && (
                <button className={styles.clearBtn} onClick={this._onClear.bind(this)} title="Clear all">
                  ✕ Clear
                </button>
              )}
            </div>
          </div>

          {/* Brand No filter chips + Search button */}
          <div className={styles.filterRow}>
            {brandOptions.length > 0 && (
              <div className={styles.filterGroup}>
                <span className={styles.filterLabel}>Brand No</span>
                <div className={styles.chips}>
                  {["All", ...brandOptions].map(b => (
                    <button
                      key={b}
                      className={`${styles.chip} ${brandFilter === b ? styles.chipActive : ""}`}
                      onClick={() => this.setState({ brandFilter: b }, () => hasSearched && this._doSearch())}
                    >{b}</button>
                  ))}
                </div>
              </div>
            )}
            <button
              className={styles.searchBtn}
              onClick={() => this._doSearch()}
              disabled={!selectedLibrary || isSearching}
            >
              {isSearching ? <span className={styles.spinner} /> : "Search"}
            </button>
          </div>
        </div>

        {/* ── Error ───────────────────────────────────────────────────────── */}
        {errorMessage && (
          <div className={styles.errorBar}>
            <span>⚠️ {errorMessage}</span>
            <button onClick={() => this.setState({ errorMessage: "" })}>✕</button>
          </div>
        )}

        {/* ── Searching indicator ─────────────────────────────────────────── */}
        {isSearching && (
          <div className={styles.searching}>
            <div className={styles.searchingDots}><span /><span /><span /></div>
            <span>Searching across all folders…</span>
          </div>
        )}

        {/* ── Results ─────────────────────────────────────────────────────── */}
        {hasSearched && !isSearching && (
          <div className={styles.resultsSection}>

            <div className={styles.resultsMeta}>
              <span className={styles.resultsCount}>
                {results.length === 0 ? "No documents found" : `${results.length} document${results.length !== 1 ? "s" : ""} found`}
              </span>
              {results.length > 0 && (
                <span className={styles.resultsIn}>
                  in <strong>{selectedLibrary}</strong>
                  <span className={styles.recursiveBadge}>🔁 All folders searched</span>
                </span>
              )}
            </div>

            {results.length > 0 && (
              <div className={styles.resultsList}>
                {results.map(item => {
                  const isExpanded = expandedItemId === item.id;
                  return (
                    <div key={item.id} className={`${styles.resultCard} ${isExpanded ? styles.resultCardExpanded : ""}`}>

                      {/* ── Card summary row ── */}
                      <div className={styles.cardMain} onClick={() => this._toggleExpand(item.id)}>
                        <div className={styles.cardEmoji}>{getFileEmoji(item)}</div>

                        <div className={styles.cardBody}>
                          {/* Title + file link */}
                          <div className={styles.cardTitleRow}>
                            {item.fileRef ? (
                              <a href={item.fileRef} target="_blank" rel="noopener noreferrer"
                                className={styles.cardTitle} onClick={e => e.stopPropagation()}>
                                {highlight(item.name || item.fileName, searchText)}
                              </a>
                            ) : (
                              <span className={styles.cardTitle}>{highlight(item.name || item.fileName, searchText)}</span>
                            )}
                            {item.brandNo && (
                              <span className={styles.brandBadge}>
                                🏷️ {highlight(item.brandNo, searchText)}
                              </span>
                            )}
                          </div>

                          {/* Quick meta chips */}
                          <div className={styles.cardMeta}>
                            <span className={styles.metaChip} title="Item ID">
                              <span className={styles.metaLabel}>#ID</span> {item.id}
                            </span>
                            {item.title && item.title !== item.name && (
                              <span className={styles.metaChip}>
                                <span className={styles.metaLabel}>Title</span>
                                {highlight(item.title, searchText)}
                              </span>
                            )}
                            {item.productNo && (
                              <span className={styles.metaChip}>
                                <span className={styles.metaLabel}>Prod#</span>
                                {highlight(item.productNo, searchText)}
                              </span>
                            )}
                            {item.brandNo && (
                              <span className={styles.metaChip}>
                                <span className={styles.metaLabel}>Brand#</span>
                                {highlight(item.brandNo, searchText)}
                              </span>
                            )}
                            {item.folderPath && (
                              <span className={styles.metaChip} title={`Path: ${item.folderPath}`}>
                                <span className={styles.metaLabel}>📁</span>
                                <span className={styles.folderPathInline}>{item.folderPath}</span>
                              </span>
                            )}
                          </div>

                          {/* Description preview */}
                          {item.description && (
                            <div className={styles.descPreview}>
                              {highlight(
                                item.description.length > 120
                                  ? item.description.slice(0, 120) + "…"
                                  : item.description,
                                searchText
                              )}
                            </div>
                          )}
                        </div>

                        <div className={styles.cardActions}>
                          {item.fileRef && (
                            <a href={item.fileRef} target="_blank" rel="noopener noreferrer"
                              className={styles.openBtn} onClick={e => e.stopPropagation()} title="Open file">
                              Open ↗
                            </a>
                          )}
                          <button
                            className={`${styles.expandBtn} ${isExpanded ? styles.expandBtnOpen : ""}`}
                            title={isExpanded ? "Collapse" : "View all details"}
                          >▾</button>
                        </div>
                      </div>

                      {/* ── Expanded details panel ── */}
                      {isExpanded && (
                        <div className={styles.cardDetails}>
                          <div className={styles.detailsGrid}>

                            <div className={styles.detailItem}>
                              <span className={styles.detailLabel}>Item ID</span>
                              <span className={styles.detailValue}>{item.id}</span>
                            </div>

                            <div className={styles.detailItem}>
                              <span className={styles.detailLabel}>Title</span>
                              <span className={styles.detailValue}>{item.title || "—"}</span>
                            </div>

                            <div className={styles.detailItem}>
                              <span className={styles.detailLabel}>Name</span>
                              <span className={styles.detailValue}>{item.name || "—"}</span>
                            </div>

                            <div className={styles.detailItem}>
                              <span className={styles.detailLabel}>Product No</span>
                              <span className={`${styles.detailValue} ${styles.monoValue}`}>
                                {item.productNo || "—"}
                              </span>
                            </div>

                            <div className={styles.detailItem}>
                              <span className={styles.detailLabel}>Brand No</span>
                              <span className={`${styles.detailValue} ${styles.monoValue}`}>
                                {item.brandNo || "—"}
                              </span>
                            </div>

                            <div className={styles.detailItem}>
                              <span className={styles.detailLabel}>File Name</span>
                              <span className={styles.detailValue}>{item.fileName || "—"}</span>
                            </div>

                            <div className={styles.detailItem}>
                              <span className={styles.detailLabel}>Folder (Immediate)</span>
                              <span className={styles.detailValue}>{item.folderName || "(Root)"}</span>
                            </div>

                            <div className={`${styles.detailItem} ${styles.detailItemWide}`}>
                              <span className={styles.detailLabel}>📁 Full Folder Path</span>
                              <span className={styles.detailValue}>
                                <span className={styles.folderBreadcrumb}>
                                  <span className={styles.folderCrumb}>{item.libraryTitle}</span>
                                  {item.folderPath && item.folderPath !== "(Root)" &&
                                    item.folderPath.split(" / ").map((seg, i) => (
                                      <span key={i} className={styles.folderCrumbWrap}>
                                        <span className={styles.folderSep}>›</span>
                                        <span className={styles.folderCrumb}>{seg}</span>
                                      </span>
                                    ))
                                  }
                                </span>
                              </span>
                            </div>

                            <div className={`${styles.detailItem} ${styles.detailItemWide}`}>
                              <span className={styles.detailLabel}>Description</span>
                              <span className={styles.detailValue}>{item.description || "—"}</span>
                            </div>

                            <div className={styles.detailItem}>
                              <span className={styles.detailLabel}>Modified</span>
                              <span className={styles.detailValue}>{formatDate(item.modified)}</span>
                            </div>

                            <div className={styles.detailItem}>
                              <span className={styles.detailLabel}>Modified By</span>
                              <span className={styles.detailValue}>{item.modifiedBy || "—"}</span>
                            </div>

                            <div className={styles.detailItem}>
                              <span className={styles.detailLabel}>Created</span>
                              <span className={styles.detailValue}>{formatDate(item.created)}</span>
                            </div>

                            <div className={styles.detailItem}>
                              <span className={styles.detailLabel}>File Size</span>
                              <span className={styles.detailValue}>{formatSize(item.fileSize) || "—"}</span>
                            </div>

                          </div>

                          {item.fileRef && (
                            <div className={styles.detailLink}>
                              <span className={styles.detailLabel}>🔗 File URL</span>
                              <a href={item.fileRef} target="_blank" rel="noopener noreferrer" className={styles.fileLink}>
                                {item.fileRef}
                              </a>
                            </div>
                          )}
                        </div>
                      )}
                    </div>
                  );
                })}
              </div>
            )}

            {results.length === 0 && !errorMessage && (
              <div className={styles.emptyState}>
                <div className={styles.emptyIcon}>🔍</div>
                <div className={styles.emptyTitle}>No documents found</div>
                <div className={styles.emptySub}>Try adjusting your search terms or Brand No filter</div>
                <button className={styles.clearFiltersBtn} onClick={this._onClear.bind(this)}>Clear all filters</button>
              </div>
            )}
          </div>
        )}

        {/* ── Idle: library quick-pick cards ──────────────────────────────── */}
        {!hasSearched && !isSearching && !errorMessage && (
          <div className={styles.idleState}>
            <div className={styles.idleGrid}>
              {libraries.slice(0, 6).map(lib => (
                <button key={lib.id} className={styles.libraryCard}
                  onClick={() => { this._onLibraryChange(lib.title); this.setState({ selectedLibrary: lib.title }); }}>
                  <span className={styles.libIcon}>📚</span>
                  <span className={styles.libName}>{lib.title}</span>
                  <span className={styles.libCount}>{lib.itemCount} items</span>
                </button>
              ))}
            </div>
            {libraries.length === 0 && !isLoadingLibraries && (
              <p className={styles.idleHint}>Select a document library above to begin searching.</p>
            )}
          </div>
        )}

      </div>
    );
  }
}
