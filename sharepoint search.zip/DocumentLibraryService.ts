// DocumentLibraryService.ts
// Service class to interact with SharePoint REST API and fetch document library columns

import { WebPartContext } from "@microsoft/sp-webpart-base";
import { SPHttpClient, SPHttpClientResponse } from "@microsoft/sp-http";
import { IDocumentItem } from "../components/IDocumentItem";

export interface IDocumentLibraryServiceConfig {
  context: WebPartContext;
  siteUrl: string;
  libraryTitle: string;
}

export class DocumentLibraryService {
  private context: WebPartContext;
  private siteUrl: string;
  private libraryTitle: string;

  // These are the internal SharePoint column names to retrieve
  // Adjust these to match your actual column internal names in SharePoint
  private readonly SELECT_FIELDS = [
    "Id",
    "FileLeafRef",                // File Name (leaf)
    "FileRef",                    // Full server-relative URL
    "Title",                      // Title / Name
    "RegistrationNumber",         // Custom: Registration Number
    "Owner/Title",                // Owner (user field) - expanded
    "DocumentStatus",             // Custom: Status column
    "DocumentType",               // Custom: Document Type column
    "FileDirRef",                 // Folder path (directory reference)
    "FSObjType",                  // 0 = file, 1 = folder
    "Created",
    "Modified",
    "Editor/Title",               // Modified By (user field) - expanded
    "File_x0020_Size",            // File Size
    "ContentType"                 // Content Type
  ].join(",");

  // Expand user fields
  private readonly EXPAND_FIELDS = "Owner,Editor,File";

  constructor(config: IDocumentLibraryServiceConfig) {
    this.context = config.context;
    this.siteUrl = config.siteUrl || config.context.pageContext.web.absoluteUrl;
    this.libraryTitle = config.libraryTitle;
  }

  /**
   * Fetches all items from the document library, including files and folders
   * @param folderPath - Optional: server-relative folder path to fetch items from
   * @param pageSize - Number of items per page
   * @param skipToken - Paging token
   */
  public async getDocumentLibraryItems(
    folderPath?: string,
    pageSize: number = 50,
    skipToken?: string
  ): Promise<{ items: IDocumentItem[]; nextPageToken: string | null }> {
    try {
      let apiUrl = `${this.siteUrl}/_api/web/lists/getByTitle('${encodeURIComponent(this.libraryTitle)}')/items`;

      const queryParams: string[] = [
        `$select=${this.SELECT_FIELDS}`,
        `$expand=${this.EXPAND_FIELDS}`,
        `$top=${pageSize}`,
        `$orderby=FSObjType desc, FileLeafRef asc`  // Folders first, then files
      ];

      // Filter by folder if specified
      if (folderPath) {
        queryParams.push(`$filter=FileDirRef eq '${encodeURIComponent(folderPath)}'`);
      }

      if (skipToken) {
        queryParams.push(`$skiptoken=${skipToken}`);
      }

      apiUrl += "?" + queryParams.join("&");

      const response: SPHttpClientResponse = await this.context.spHttpClient.get(
        apiUrl,
        SPHttpClient.configurations.v1,
        {
          headers: {
            Accept: "application/json;odata=nometadata",
            "Content-Type": "application/json;odata=nometadata"
          }
        }
      );

      if (!response.ok) {
        const errorText = await response.text();
        throw new Error(`Failed to fetch document library items: ${response.status} - ${errorText}`);
      }

      const data = await response.json();
      const rawItems = data.value || [];

      // Extract next page token if available
      const nextPageToken = data["odata.nextLink"]
        ? this._extractSkipToken(data["odata.nextLink"])
        : null;

      const items: IDocumentItem[] = rawItems.map((item: any) =>
        this._mapToDocumentItem(item)
      );

      return { items, nextPageToken };
    } catch (error) {
      console.error("[DocumentLibraryService] Error fetching items:", error);
      throw error;
    }
  }

  /**
   * Fetches column schema/metadata for the library
   */
  public async getLibraryColumns(): Promise<any[]> {
    try {
      const apiUrl = `${this.siteUrl}/_api/web/lists/getByTitle('${encodeURIComponent(this.libraryTitle)}')/fields?$filter=Hidden eq false and ReadOnlyField eq false`;

      const response: SPHttpClientResponse = await this.context.spHttpClient.get(
        apiUrl,
        SPHttpClient.configurations.v1,
        {
          headers: {
            Accept: "application/json;odata=nometadata"
          }
        }
      );

      if (!response.ok) {
        throw new Error(`Failed to fetch library columns: ${response.status}`);
      }

      const data = await response.json();
      return data.value || [];
    } catch (error) {
      console.error("[DocumentLibraryService] Error fetching columns:", error);
      throw error;
    }
  }

  /**
   * Fetches a single item by ID
   */
  public async getItemById(itemId: number): Promise<IDocumentItem | null> {
    try {
      const apiUrl = `${this.siteUrl}/_api/web/lists/getByTitle('${encodeURIComponent(this.libraryTitle)}')/items(${itemId})?$select=${this.SELECT_FIELDS}&$expand=${this.EXPAND_FIELDS}`;

      const response: SPHttpClientResponse = await this.context.spHttpClient.get(
        apiUrl,
        SPHttpClient.configurations.v1,
        {
          headers: {
            Accept: "application/json;odata=nometadata"
          }
        }
      );

      if (!response.ok) {
        throw new Error(`Failed to fetch item ${itemId}: ${response.status}`);
      }

      const item = await response.json();
      return this._mapToDocumentItem(item);
    } catch (error) {
      console.error(`[DocumentLibraryService] Error fetching item ${itemId}:`, error);
      return null;
    }
  }

  /**
   * Searches for items in the document library by name or registration number
   */
  public async searchItems(
    searchText: string,
    statusFilter?: string,
    typeFilter?: string
  ): Promise<IDocumentItem[]> {
    try {
      let filterParts: string[] = [];

      if (searchText) {
        filterParts.push(
          `(substringof('${searchText}', FileLeafRef) or substringof('${searchText}', RegistrationNumber) or substringof('${searchText}', Title))`
        );
      }

      if (statusFilter && statusFilter !== "All") {
        filterParts.push(`DocumentStatus eq '${statusFilter}'`);
      }

      if (typeFilter && typeFilter !== "All") {
        filterParts.push(`DocumentType eq '${typeFilter}'`);
      }

      let apiUrl = `${this.siteUrl}/_api/web/lists/getByTitle('${encodeURIComponent(this.libraryTitle)}')/items?$select=${this.SELECT_FIELDS}&$expand=${this.EXPAND_FIELDS}&$top=500`;

      if (filterParts.length > 0) {
        apiUrl += `&$filter=${filterParts.join(" and ")}`;
      }

      const response: SPHttpClientResponse = await this.context.spHttpClient.get(
        apiUrl,
        SPHttpClient.configurations.v1,
        {
          headers: {
            Accept: "application/json;odata=nometadata"
          }
        }
      );

      if (!response.ok) {
        throw new Error(`Search failed: ${response.status}`);
      }

      const data = await response.json();
      return (data.value || []).map((item: any) => this._mapToDocumentItem(item));
    } catch (error) {
      console.error("[DocumentLibraryService] Error searching items:", error);
      throw error;
    }
  }

  /**
   * Gets unique status values from the library for filter dropdown
   */
  public async getStatusValues(): Promise<string[]> {
    try {
      const apiUrl = `${this.siteUrl}/_api/web/lists/getByTitle('${encodeURIComponent(this.libraryTitle)}')/fields/getByInternalNameOrTitle('DocumentStatus')?$select=Choices`;

      const response: SPHttpClientResponse = await this.context.spHttpClient.get(
        apiUrl,
        SPHttpClient.configurations.v1,
        {
          headers: {
            Accept: "application/json;odata=nometadata"
          }
        }
      );

      if (!response.ok) return [];

      const data = await response.json();
      return data.Choices || [];
    } catch {
      return ["Draft", "In Review", "Approved", "Published", "Archived"];
    }
  }

  /**
   * Gets unique document type values for filter dropdown
   */
  public async getDocumentTypeValues(): Promise<string[]> {
    try {
      const apiUrl = `${this.siteUrl}/_api/web/lists/getByTitle('${encodeURIComponent(this.libraryTitle)}')/fields/getByInternalNameOrTitle('DocumentType')?$select=Choices`;

      const response: SPHttpClientResponse = await this.context.spHttpClient.get(
        apiUrl,
        SPHttpClient.configurations.v1,
        {
          headers: {
            Accept: "application/json;odata=nometadata"
          }
        }
      );

      if (!response.ok) return [];

      const data = await response.json();
      return data.Choices || [];
    } catch {
      return ["Policy", "Procedure", "Form", "Report", "Contract", "Invoice"];
    }
  }

  // ─── Private Helpers ────────────────────────────────────────────────────────

  /**
   * Maps raw SharePoint REST API item to IDocumentItem interface
   */
  private _mapToDocumentItem(item: any): IDocumentItem {
    const fileLeafRef: string = item["FileLeafRef"] || "";
    const fileDirRef: string = item["FileDirRef"] || "";
    const isFolder: boolean = item["FSObjType"] === 1;

    // Extract folder name from FileDirRef (last segment of path)
    const folderSegments = fileDirRef.split("/");
    const folderName = folderSegments[folderSegments.length - 1] || "";

    // Determine file extension / type
    const fileExtension = isFolder
      ? "Folder"
      : fileLeafRef.includes(".")
      ? fileLeafRef.split(".").pop()?.toUpperCase() || "Unknown"
      : "Unknown";

    return {
      id: item["Id"] || 0,
      name: item["Title"] || fileLeafRef || "(No Title)",
      registrationNumber: item["RegistrationNumber"] || "",
      owner: item["Owner"]?.Title || item["Author"]?.Title || "",
      status: item["DocumentStatus"] || "",
      type: item["DocumentType"] || item["ContentType"] || fileExtension,
      fileName: fileLeafRef,
      folderName: folderName,
      fileRef: item["FileRef"] || "",
      created: item["Created"] || "",
      modified: item["Modified"] || "",
      modifiedBy: item["Editor"]?.Title || "",
      fileSize: item["File_x0020_Size"] || 0,
      isFolder: isFolder
    };
  }

  private _extractSkipToken(nextLink: string): string {
    const match = nextLink.match(/\$skiptoken=([^&]+)/);
    return match ? decodeURIComponent(match[1]) : "";
  }
}
