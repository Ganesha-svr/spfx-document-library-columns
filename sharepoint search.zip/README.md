# SPFx Document Library Columns Web Part

A SharePoint Framework (SPFx) web part that retrieves and displays document library items with the following columns:

| Column | Source | Notes |
|--------|--------|-------|
| **Name** | `Title` / `FileLeafRef` | Item title or file name |
| **Registration Number** | `RegistrationNumber` | Custom column |
| **Owner** | `Owner/Title` | User field (expanded) |
| **Status** | `DocumentStatus` | Choice column |
| **Type** | `DocumentType` | Choice column / file extension |
| **File Name** | `FileLeafRef` | Actual file name with extension |
| **Folder Name** | `FileDirRef` | Parent folder derived from path |

---

## Features

- 📂 Folder navigation with breadcrumb trail
- 🔍 Full-text search across Name, Registration Number
- 🎛️ Filter by Status and Document Type
- 🗂️ Sortable columns (click any column header)
- ✅ Multi-select with selection count
- 📄 Pagination support (configurable page size)
- 🎨 Status badges with color coding
- 📁 Toggle folder visibility
- 🌐 Cross-site library support via Site URL configuration

---

## Prerequisites

- Node.js v16 or v18 LTS
- SPFx 1.18.2 compatible environment
- SharePoint Online tenant
- Yeoman & Gulp CLI:

```bash
npm install -g yo gulp-cli @microsoft/generator-sharepoint
```

---

## Project Structure

```
spfx-document-library-columns/
├── config/
│   ├── config.json                          # Bundle configuration
│   └── package-solution.json               # Solution packaging
├── src/
│   └── webparts/
│       └── documentLibraryColumns/
│           ├── components/
│           │   ├── DocumentLibraryColumns.tsx       # Main React component
│           │   ├── DocumentLibraryColumns.module.scss  # Styles
│           │   └── IDocumentItem.ts                 # TypeScript interfaces
│           ├── services/
│           │   └── DocumentLibraryService.ts        # SharePoint REST API service
│           ├── DocumentLibraryColumnsWebPart.ts     # WebPart entry point
│           └── DocumentLibraryColumnsWebPart.manifest.json
├── package.json
├── tsconfig.json
├── gulpfile.js
└── README.md
```

---

## Installation & Build

```bash
# 1. Clone / extract this project
cd spfx-document-library-columns

# 2. Install dependencies
npm install

# 3. Run in development mode
gulp serve

# 4. Build for production
gulp bundle --ship
gulp package-solution --ship
```

---

## Deployment to SharePoint

1. After running `gulp package-solution --ship`, find the `.sppkg` file:
   ```
   sharepoint/solution/spfx-document-library-columns.sppkg
   ```

2. Upload to your **SharePoint App Catalog**:
   - Go to: `https://<tenant>.sharepoint.com/sites/appcatalog/AppCatalog`
   - Upload the `.sppkg` file
   - Check **"Make this solution available to all sites"** for tenant-wide deployment

3. Add the web part to any SharePoint page via the modern web part picker.

---

## Configuration (Property Pane)

| Setting | Description | Default |
|---------|-------------|---------|
| Document Library Title | Exact title of the library | `Documents` |
| Site URL | Full URL for cross-site libraries | (current site) |
| Items Per Page | Number of rows per load (10–500) | `50` |
| Show Folders | Toggle folder visibility | `true` |

---

## Customizing Column Internal Names

Open `src/webparts/documentLibraryColumns/services/DocumentLibraryService.ts` and modify the `SELECT_FIELDS` array to match your SharePoint column internal names:

```typescript
private readonly SELECT_FIELDS = [
  "Id",
  "FileLeafRef",            // File name
  "FileRef",                // Full URL
  "Title",                  // Name
  "RegistrationNumber",     // ← Change to your column's internal name
  "Owner/Title",            // ← Change if your Owner field is different
  "DocumentStatus",         // ← Change to your Status column internal name
  "DocumentType",           // ← Change to your Type column internal name
  "FileDirRef",             // Folder path
  "FSObjType",              // File vs Folder flag
  "Created",
  "Modified",
  "Editor/Title",
  "File_x0020_Size"
].join(",");
```

### How to find internal column names

1. Go to **Library Settings** → click a column
2. Check the URL — the `Field=` parameter is the internal name
3. Or use: `https://<site>/_api/web/lists/getByTitle('<Library>')/fields?$select=Title,InternalName`

---

## Status Badge Colors

The following status values have built-in color coding (edit `DocumentLibraryColumns.module.scss` to customize):

| Status | Color |
|--------|-------|
| Draft | Grey |
| In Review | Yellow |
| Approved | Green |
| Published | Blue |
| Archived | Light grey |
| Rejected | Red |

---

## REST API Endpoints Used

| Purpose | Endpoint |
|---------|----------|
| Fetch items | `/_api/web/lists/getByTitle('{library}')/items` |
| Fetch columns | `/_api/web/lists/getByTitle('{library}')/fields` |
| Fetch single item | `/_api/web/lists/getByTitle('{library}')/items({id})` |
| Get choice values | `/_api/web/lists/getByTitle('{library}')/fields/getByInternalNameOrTitle('{field}')` |

---

## License

MIT
