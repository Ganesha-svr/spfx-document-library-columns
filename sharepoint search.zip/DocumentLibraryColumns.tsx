// DocumentLibraryColumns.tsx
// Main React component for rendering the document library columns

import * as React from "react";
import {
  DetailsList,
  DetailsListLayoutMode,
  IColumn,
  SelectionMode,
  Selection,
  IDetailsListProps,
} from "office-ui-fabric-react/lib/DetailsList";
import {
  SearchBox,
} from "office-ui-fabric-react/lib/SearchBox";
import {
  Dropdown,
  IDropdownOption,
} from "office-ui-fabric-react/lib/Dropdown";
import {
  Spinner,
  SpinnerSize,
} from "office-ui-fabric-react/lib/Spinner";
import {
  MessageBar,
  MessageBarType,
} from "office-ui-fabric-react/lib/MessageBar";
import {
  Breadcrumb,
  IBreadcrumbItem,
} from "office-ui-fabric-react/lib/Breadcrumb";
import {
  CommandBar,
  ICommandBarItemProps,
} from "office-ui-fabric-react/lib/CommandBar";
import { Icon } from "office-ui-fabric-react/lib/Icon";
import { Link } from "office-ui-fabric-react/lib/Link";
import { Stack } from "office-ui-fabric-react/lib/Stack";
import { Text } from "office-ui-fabric-react/lib/Text";

import {
  IDocumentItem,
  IDocumentLibraryState,
  IDocumentLibraryColumnsProps,
  IBreadcrumb,
} from "./IDocumentItem";
import { DocumentLibraryService } from "../services/DocumentLibraryService";
import styles from "./DocumentLibraryColumns.module.scss";

export default class DocumentLibraryColumns extends React.Component<
  IDocumentLibraryColumnsProps,
  IDocumentLibraryState
> {
  private _service: DocumentLibraryService;
  private _selection: Selection;
  private _statusOptions: IDropdownOption[] = [{ key: "All", text: "All Statuses" }];
  private _typeOptions: IDropdownOption[] = [{ key: "All", text: "All Types" }];

  constructor(props: IDocumentLibraryColumnsProps) {
    super(props);

    this._service = new DocumentLibraryService({
      context: props.context,
      siteUrl: props.siteUrl,
      libraryTitle: props.libraryTitle,
    });

    this._selection = new Selection({
      onSelectionChanged: () => {
        const selected = this._selection.getSelection() as IDocumentItem[];
        this.setState({ selectedItems: selected.map((i) => i.id) });
      },
    });

    this.state = {
      items: [],
      isLoading: true,
      errorMessage: "",
      currentFolder: "",
      breadcrumbs: [{ name: props.libraryTitle, folderPath: "" }],
      filterText: "",
      filterStatus: "All",
      filterType: "All",
      sortColumn: "name",
      sortAscending: true,
      selectedItems: [],
      pageSize: props.pageSize || 50,
      currentPage: 1,
    };
  }

  public async componentDidMount(): Promise<void> {
    await this._loadData();
    await this._loadFilterOptions();
  }

  public async componentDidUpdate(prevProps: IDocumentLibraryColumnsProps): Promise<void> {
    if (
      prevProps.libraryTitle !== this.props.libraryTitle ||
      prevProps.siteUrl !== this.props.siteUrl
    ) {
      this._service = new DocumentLibraryService({
        context: this.props.context,
        siteUrl: this.props.siteUrl,
        libraryTitle: this.props.libraryTitle,
      });
      await this._loadData();
    }
  }

  private async _loadData(folderPath?: string): Promise<void> {
    this.setState({ isLoading: true, errorMessage: "" });
    try {
      const { items } = await this._service.getDocumentLibraryItems(
        folderPath,
        this.state.pageSize
      );
      this.setState({ items, isLoading: false });
    } catch (error) {
      this.setState({
        isLoading: false,
        errorMessage: `Failed to load documents: ${error.message}`,
      });
    }
  }

  private async _loadFilterOptions(): Promise<void> {
    const statuses = await this._service.getStatusValues();
    const types = await this._service.getDocumentTypeValues();

    this._statusOptions = [
      { key: "All", text: "All Statuses" },
      ...statuses.map((s) => ({ key: s, text: s })),
    ];
    this._typeOptions = [
      { key: "All", text: "All Types" },
      ...types.map((t) => ({ key: t, text: t })),
    ];
    this.forceUpdate();
  }

  // ─── Column Definitions ───────────────────────────────────────────────────

  private _getColumns(): IColumn[] {
    const { sortColumn, sortAscending } = this.state;

    const col = (
      key: string,
      name: string,
      fieldName: string,
      minWidth: number,
      maxWidth: number,
      onRender?: (item: IDocumentItem) => JSX.Element
    ): IColumn => ({
      key,
      name,
      fieldName,
      minWidth,
      maxWidth,
      isResizable: true,
      isSorted: sortColumn === key,
      isSortedDescending: sortColumn === key && !sortAscending,
      onColumnClick: () => this._onColumnHeaderClick(key),
      onRender,
    });

    return [
      col("name", "Name", "name", 200, 300, (item) => (
        <Stack horizontal verticalAlign="center" tokens={{ childrenGap: 6 }}>
          <Icon
            iconName={item.isFolder ? "FabricFolder" : this._getFileIcon(item.fileName)}
            styles={{ root: { fontSize: 16, color: item.isFolder ? "#ffb900" : "#0078d4" } }}
          />
          {item.isFolder ? (
            <Link onClick={() => this._onFolderClick(item)}>{item.name || item.fileName}</Link>
          ) : (
            <Link href={item.fileRef} target="_blank">{item.name || item.fileName}</Link>
          )}
        </Stack>
      )),
      col("registrationNumber", "Registration No.", "registrationNumber", 130, 180),
      col("owner", "Owner", "owner", 120, 160),
      col("status", "Status", "status", 100, 140, (item) => (
        <span className={`${styles.statusBadge} ${styles[`status_${item.status?.toLowerCase().replace(/\s/g, "_")}`]}`}>
          {item.status || "—"}
        </span>
      )),
      col("type", "Type", "type", 80, 120),
      col("fileName", "File Name", "fileName", 150, 250),
      col("folderName", "Folder", "folderName", 120, 180),
      col("modified", "Modified", "modified", 120, 160, (item) => (
        <span>{item.modified ? new Date(item.modified).toLocaleDateString() : "—"}</span>
      )),
      col("modifiedBy", "Modified By", "modifiedBy", 120, 160),
      col("fileSize", "Size", "fileSize", 80, 100, (item) => (
        <span>{item.isFolder ? "—" : this._formatFileSize(item.fileSize)}</span>
      )),
    ];
  }

  // ─── Event Handlers ───────────────────────────────────────────────────────

  private _onColumnHeaderClick(columnKey: string): void {
    const { sortColumn, sortAscending } = this.state;
    this.setState({
      sortColumn: columnKey,
      sortAscending: sortColumn === columnKey ? !sortAscending : true,
    });
  }

  private async _onFolderClick(item: IDocumentItem): Promise<void> {
    const newBreadcrumbs: IBreadcrumb[] = [
      ...this.state.breadcrumbs,
      { name: item.fileName, folderPath: item.fileRef },
    ];
    this.setState({ breadcrumbs: newBreadcrumbs, currentFolder: item.fileRef });
    await this._loadData(item.fileRef);
  }

  private async _onBreadcrumbClick(folderPath: string, index: number): Promise<void> {
    const newBreadcrumbs = this.state.breadcrumbs.slice(0, index + 1);
    this.setState({ breadcrumbs: newBreadcrumbs, currentFolder: folderPath });
    await this._loadData(folderPath || undefined);
  }

  private async _onSearch(text: string): Promise<void> {
    this.setState({ filterText: text, isLoading: true });
    try {
      const items = await this._service.searchItems(
        text,
        this.state.filterStatus,
        this.state.filterType
      );
      this.setState({ items, isLoading: false });
    } catch {
      this.setState({ isLoading: false });
    }
  }

  private async _onStatusFilter(option: IDropdownOption): Promise<void> {
    this.setState({ filterStatus: option.key as string, isLoading: true });
    try {
      const items = await this._service.searchItems(
        this.state.filterText,
        option.key as string,
        this.state.filterType
      );
      this.setState({ items, isLoading: false });
    } catch {
      this.setState({ isLoading: false });
    }
  }

  private async _onTypeFilter(option: IDropdownOption): Promise<void> {
    this.setState({ filterType: option.key as string, isLoading: true });
    try {
      const items = await this._service.searchItems(
        this.state.filterText,
        this.state.filterStatus,
        option.key as string
      );
      this.setState({ items, isLoading: false });
    } catch {
      this.setState({ isLoading: false });
    }
  }

  private async _onRefresh(): Promise<void> {
    this.setState({ filterText: "", filterStatus: "All", filterType: "All" });
    await this._loadData(this.state.currentFolder || undefined);
  }

  // ─── Helpers ──────────────────────────────────────────────────────────────

  private _getSortedItems(): IDocumentItem[] {
    const { items, sortColumn, sortAscending, showFolders } = { ...this.state, showFolders: this.props.showFolders };
    let filtered = showFolders ? items : items.filter((i) => !i.isFolder);

    return filtered.sort((a, b) => {
      // Always folders first
      if (a.isFolder !== b.isFolder) return a.isFolder ? -1 : 1;

      const valA = (a as any)[sortColumn] || "";
      const valB = (b as any)[sortColumn] || "";
      const cmp = typeof valA === "string"
        ? valA.localeCompare(valB)
        : valA - valB;
      return sortAscending ? cmp : -cmp;
    });
  }

  private _formatFileSize(bytes: number): string {
    if (!bytes) return "0 B";
    const k = 1024;
    const sizes = ["B", "KB", "MB", "GB"];
    const i = Math.floor(Math.log(bytes) / Math.log(k));
    return `${parseFloat((bytes / Math.pow(k, i)).toFixed(1))} ${sizes[i]}`;
  }

  private _getFileIcon(fileName: string): string {
    const ext = fileName?.split(".").pop()?.toLowerCase();
    const iconMap: { [key: string]: string } = {
      pdf: "PDF",
      doc: "WordDocument",
      docx: "WordDocument",
      xls: "ExcelDocument",
      xlsx: "ExcelDocument",
      ppt: "PowerPointDocument",
      pptx: "PowerPointDocument",
      txt: "TextDocument",
      png: "FileImage",
      jpg: "FileImage",
      jpeg: "FileImage",
      gif: "FileImage",
      zip: "ZipFolder",
      msg: "Mail",
    };
    return iconMap[ext || ""] || "Document";
  }

  private _getBreadcrumbItems(): IBreadcrumbItem[] {
    return this.state.breadcrumbs.map((b, idx) => ({
      text: b.name,
      key: `bc_${idx}`,
      onClick: () => this._onBreadcrumbClick(b.folderPath, idx),
    }));
  }

  private _getCommandBarItems(): ICommandBarItemProps[] {
    return [
      {
        key: "refresh",
        text: "Refresh",
        iconProps: { iconName: "Refresh" },
        onClick: () => this._onRefresh(),
      },
      {
        key: "itemCount",
        text: `${this._getSortedItems().length} item(s)`,
        disabled: true,
        iconProps: { iconName: "BulletedList" },
      },
    ];
  }

  // ─── Render ───────────────────────────────────────────────────────────────

  public render(): JSX.Element {
    const { isLoading, errorMessage, filterText, filterStatus, filterType } = this.state;
    const sortedItems = this._getSortedItems();

    return (
      <div className={styles.documentLibraryColumns}>
        {/* Header */}
        <Stack className={styles.header} tokens={{ childrenGap: 8 }}>
          <Text variant="xLarge" className={styles.title}>
            <Icon iconName="FabricFolder" className={styles.titleIcon} />
            {this.props.libraryTitle}
          </Text>

          {/* Breadcrumb Navigation */}
          <Breadcrumb
            items={this._getBreadcrumbItems()}
            maxDisplayedItems={4}
            styles={{ root: { margin: 0 } }}
          />
        </Stack>

        {/* Command Bar */}
        <CommandBar items={this._getCommandBarItems()} styles={{ root: { padding: 0 } }} />

        {/* Filters Row */}
        <Stack horizontal tokens={{ childrenGap: 12 }} className={styles.filters}>
          <SearchBox
            placeholder="Search by name, registration number..."
            value={filterText}
            onChange={(_, val) => this._onSearch(val || "")}
            onClear={() => this._onSearch("")}
            styles={{ root: { flex: 2, minWidth: 200 } }}
          />
          <Dropdown
            placeholder="Filter by Status"
            options={this._statusOptions}
            selectedKey={filterStatus}
            onChange={(_, opt) => opt && this._onStatusFilter(opt)}
            styles={{ root: { flex: 1, minWidth: 140 } }}
          />
          <Dropdown
            placeholder="Filter by Type"
            options={this._typeOptions}
            selectedKey={filterType}
            onChange={(_, opt) => opt && this._onTypeFilter(opt)}
            styles={{ root: { flex: 1, minWidth: 140 } }}
          />
        </Stack>

        {/* Error */}
        {errorMessage && (
          <MessageBar messageBarType={MessageBarType.error} onDismiss={() => this.setState({ errorMessage: "" })}>
            {errorMessage}
          </MessageBar>
        )}

        {/* Loading */}
        {isLoading ? (
          <Stack horizontalAlign="center" tokens={{ padding: 40 }}>
            <Spinner size={SpinnerSize.large} label="Loading documents..." />
          </Stack>
        ) : (
          <>
            {/* Empty state */}
            {sortedItems.length === 0 ? (
              <Stack horizontalAlign="center" tokens={{ padding: 40 }}>
                <Icon iconName="FabricFolderSearch" styles={{ root: { fontSize: 48, color: "#a19f9d" } }} />
                <Text variant="large" styles={{ root: { color: "#a19f9d", marginTop: 12 } }}>
                  No documents found
                </Text>
              </Stack>
            ) : (
              /* Document List */
              <DetailsList
                items={sortedItems}
                columns={this._getColumns()}
                layoutMode={DetailsListLayoutMode.justified}
                selectionMode={SelectionMode.multiple}
                selection={this._selection}
                isHeaderVisible={true}
                className={styles.detailsList}
                getKey={(item: IDocumentItem) => item.id.toString()}
              />
            )}
          </>
        )}
      </div>
    );
  }
}
