// DocumentLibraryColumnsWebPart.ts
// SPFx WebPart entry point - bootstraps the React component

import * as React from "react";
import * as ReactDom from "react-dom";
import { Version } from "@microsoft/sp-core-library";
import {
  IPropertyPaneConfiguration,
  PropertyPaneTextField,
  PropertyPaneToggle,
  PropertyPaneSlider,
} from "@microsoft/sp-property-pane";
import { BaseClientSideWebPart } from "@microsoft/sp-webpart-base";
import { IReadonlyTheme } from "@microsoft/sp-component-base";

import DocumentLibraryColumns from "./components/DocumentLibraryColumns";
import { IDocumentLibraryColumnsProps } from "./components/IDocumentItem";

export interface IDocumentLibraryColumnsWebPartProps {
  libraryTitle: string;
  siteUrl: string;
  pageSize: number;
  showFolders: boolean;
}

export default class DocumentLibraryColumnsWebPart extends BaseClientSideWebPart<IDocumentLibraryColumnsWebPartProps> {
  private _themeVariant: IReadonlyTheme | undefined;

  protected onThemeChanged(currentTheme: IReadonlyTheme | undefined): void {
    if (!currentTheme) return;
    this._themeVariant = currentTheme;
    this.render();
  }

  public render(): void {
    const element: React.ReactElement<IDocumentLibraryColumnsProps> =
      React.createElement(DocumentLibraryColumns, {
        libraryTitle: this.properties.libraryTitle || "Documents",
        siteUrl: this.properties.siteUrl || this.context.pageContext.web.absoluteUrl,
        pageSize: this.properties.pageSize || 50,
        showFolders: this.properties.showFolders !== false,
        context: this.context,
        themeVariant: this._themeVariant,
      });

    ReactDom.render(element, this.domElement);
  }

  protected onDispose(): void {
    ReactDom.unmountComponentAtNode(this.domElement);
  }

  protected get dataVersion(): Version {
    return Version.parse("1.0");
  }

  protected getPropertyPaneConfiguration(): IPropertyPaneConfiguration {
    return {
      pages: [
        {
          header: {
            description: "Configure the Document Library Columns Web Part",
          },
          groups: [
            {
              groupName: "Library Settings",
              groupFields: [
                PropertyPaneTextField("libraryTitle", {
                  label: "Document Library Title",
                  description: "Enter the exact title of the SharePoint Document Library",
                  placeholder: "e.g. Documents",
                  value: this.properties.libraryTitle,
                }),
                PropertyPaneTextField("siteUrl", {
                  label: "Site URL (optional)",
                  description: "Leave blank to use the current site. For cross-site, enter the full URL.",
                  placeholder: "https://tenant.sharepoint.com/sites/mysite",
                  value: this.properties.siteUrl,
                }),
              ],
            },
            {
              groupName: "Display Settings",
              groupFields: [
                PropertyPaneSlider("pageSize", {
                  label: "Items Per Page",
                  min: 10,
                  max: 500,
                  step: 10,
                  value: this.properties.pageSize || 50,
                }),
                PropertyPaneToggle("showFolders", {
                  label: "Show Folders",
                  onText: "Yes",
                  offText: "No",
                  checked: this.properties.showFolders !== false,
                }),
              ],
            },
          ],
        },
      ],
    };
  }
}
