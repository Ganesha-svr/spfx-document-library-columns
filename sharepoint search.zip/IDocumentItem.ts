// IDocumentItem.ts
// Interface representing a document item from the SharePoint Document Library

export interface IDocumentItem {
  id: number;
  name: string;                    // File/Item name
  registrationNumber: string;      // Custom column: Registration Number
  owner: string;                   // Owner / Author of the document
  status: string;                  // Custom column: Status (e.g. Draft, Approved, Published)
  type: string;                    // Document type (e.g. PDF, DOCX, XLSX)
  fileName: string;                // Actual file name with extension
  folderName: string;              // Parent folder name
  fileRef: string;                 // Full server-relative URL to the file
  created: string;                 // Created date
  modified: string;                // Last modified date
  modifiedBy: string;              // Last modified by
  fileSize: number;                // File size in bytes
  isFolder: boolean;               // Whether the item is a folder
}

export interface IDocumentLibraryState {
  items: IDocumentItem[];
  isLoading: boolean;
  errorMessage: string;
  currentFolder: string;
  breadcrumbs: IBreadcrumb[];
  filterText: string;
  filterStatus: string;
  filterType: string;
  sortColumn: string;
  sortAscending: boolean;
  selectedItems: number[];
  pageSize: number;
  currentPage: number;
}

export interface IBreadcrumb {
  name: string;
  folderPath: string;
}

export interface IColumnConfig {
  key: string;
  name: string;
  fieldName: string;
  minWidth: number;
  maxWidth: number;
  isResizable: boolean;
  isSorted?: boolean;
  isSortedDescending?: boolean;
}

export interface IDocumentLibraryColumnsProps {
  libraryTitle: string;
  siteUrl: string;
  pageSize: number;
  showFolders: boolean;
  context: any; // SPFx WebPartContext
  themeVariant?: any;
}
