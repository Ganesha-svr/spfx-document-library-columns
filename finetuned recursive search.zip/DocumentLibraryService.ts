// DocumentLibraryService.ts  (v3 — RecursiveAll CAML Search)
//
// KEY CHANGE: searchItems() now uses a CAML POST query with Scope="RecursiveAll"
// This tells SharePoint to search ALL nested subfolders, no matter how deep.
// The old GET /items endpoint only returned root-level or single-folder items.

import { WebPartContext } from "@microsoft/sp-webpart-base";
import { SPHttpClient, SPHttpClientResponse } from "@microsoft/sp-http";
import { IDocumentItem, ILibraryInfo } from "../components/IDocumentItem";

export class DocumentLibraryService {
  private context: WebPartContext;
  private siteUrl: string;

  // Fields requested via ViewFields in CAML (must use internal names)
  private readonly CAML_FIELDS = [
    "ID", "FileLeafRef", "FileRef", "Title", "RegistrationNumber",
    "Owner", "DocumentStatus", "DocumentType", "FileDirRef",
    "FSObjType", "Created", "Modified", "Editor",
    "File_x0020_Size", "ContentType", "Author"
  ];

  constructor(context: WebPartContext, siteUrl?: string) {
    this.context = context;
    this.siteUrl = (siteUrl || context.pageContext.web.absoluteUrl).replace(/\/$/, "");
  }

  // ─── List all Document Libraries ─────────────────────────────────────────

  public async getAllDocumentLibraries(): Promise<ILibraryInfo[]> {
    try {
      const apiUrl =
        `${this.siteUrl}/_api/web/lists` +
        `?$filter=BaseType eq 1 and Hidden eq false and IsCatalog eq false` +
        `&$select=Id,Title,ItemCount,LastItemModifiedDate,DefaultViewUrl,Description` +
        `&$orderby=Title asc`;

      const response: SPHttpClientResponse = await this.context.spHttpClient.get(
        apiUrl,
        SPHttpClient.configurations.v1,
        { headers: { Accept: "application/json;odata=nometadata" } }
      );

      if (!response.ok) throw new Error(`HTTP ${response.status}`);
      const data = await response.json();

      return (data.value || []).map((lib: any): ILibraryInfo => ({
        id: lib.Id,
        title: lib.Title,
        itemCount: lib.ItemCount || 0,
        lastModified: lib.LastItemModifiedDate,
        defaultViewUrl: lib.DefaultViewUrl || "",
        description: lib.Description || ""
      }));
    } catch (error) {
      console.error("[Service] getAllDocumentLibraries:", error);
      throw error;
    }
  }

  // ─── Search Items — CAML RecursiveAll ─────────────────────────────────────
  //
  // Why CAML POST instead of GET /items?
  //   • Scope="RecursiveAll" traverses ALL subfolders at any depth
  //   • GET /items with $filter only searches the current folder level
  //   • CAML lets us combine text search + field filters cleanly
  //
  // Why "RecursiveAll" vs "Recursive"?
  //   • "Recursive"    → returns files in all subfolders, but NOT folders themselves
  //   • "RecursiveAll" → returns BOTH files AND folder items across all depths
  //     We use RecursiveAll so folder rows still show up if the user searches for one.

  public async searchItems(
    libraryTitle: string,
    searchText: string,
    statusFilter: string,
    typeFilter: string
  ): Promise<IDocumentItem[]> {
    try {
      const whereClause = this._buildWhereClause(searchText, statusFilter, typeFilter);
      const viewFields = this.CAML_FIELDS.map(f => `<FieldRef Name="${f}"/>`).join("");

      // Full CAML query — Scope="RecursiveAll" is the critical attribute
      const camlQuery = `
        <View Scope="RecursiveAll">
          <ViewFields>${viewFields}</ViewFields>
          <Query>
            <OrderBy>
              <FieldRef Name="Modified" Ascending="FALSE"/>
            </OrderBy>
            ${whereClause ? `<Where>${whereClause}</Where>` : ""}
          </Query>
          <RowLimit Paged="TRUE">500</RowLimit>
        </View>`;

      const apiUrl =
        `${this.siteUrl}/_api/web/lists/getByTitle('${encodeURIComponent(libraryTitle)}')/getItems`;

      const body = JSON.stringify({
        query: {
          __metadata: { type: "SP.CamlQuery" },
          ViewXml: camlQuery
        }
      });

      const response: SPHttpClientResponse = await this.context.spHttpClient.post(
        apiUrl,
        SPHttpClient.configurations.v1,
        {
          headers: {
            Accept: "application/json;odata=verbose",  // verbose needed for getItems POST
            "Content-Type": "application/json;odata=verbose",
            // This header prevents SharePoint from refusing queries on non-indexed columns
            Prefer: "HonorNonIndexedQueriesWarningMayFailOnLargeList"
          },
          body
        }
      );

      if (!response.ok) {
        const errText = await response.text();
        throw new Error(`Search failed (HTTP ${response.status}): ${errText}`);
      }

      const data = await response.json();
      // odata=verbose wraps results under d.results
      const rawItems: any[] = data?.d?.results || [];

      // Expand user fields (Owner, Editor, Author) from deferred objects
      const expandedItems = await this._expandUserFields(rawItems, libraryTitle);

      return expandedItems
        .map(item => this._mapToDocumentItem(item, libraryTitle))
        // Filter out hidden system items (FSObjType check already handles folders)
        .filter(item => item.fileName && item.fileName !== "");

    } catch (error) {
      console.error("[Service] searchItems (CAML RecursiveAll):", error);
      throw error;
    }
  }

  // ─── Get Choice Field Values ──────────────────────────────────────────────

  public async getChoiceValues(libraryTitle: string, fieldName: string): Promise<string[]> {
    try {
      const apiUrl =
        `${this.siteUrl}/_api/web/lists/getByTitle('${encodeURIComponent(libraryTitle)}')` +
        `/fields/getByInternalNameOrTitle('${fieldName}')?$select=Choices`;

      const response: SPHttpClientResponse = await this.context.spHttpClient.get(
        apiUrl,
        SPHttpClient.configurations.v1,
        { headers: { Accept: "application/json;odata=nometadata" } }
      );

      if (!response.ok) return [];
      const data = await response.json();
      return data.Choices || [];
    } catch {
      return [];
    }
  }

  // ─── Private: Build CAML Where Clause ────────────────────────────────────

  private _buildWhereClause(
    searchText: string,
    statusFilter: string,
    typeFilter: string
  ): string {
    const conditions: string[] = [];

    // Text search — OR across FileLeafRef (file name), Title, RegistrationNumber
    if (searchText && searchText.trim()) {
      const q = this._escapeXml(searchText.trim());
      conditions.push(`
        <Or>
          <Or>
            <Contains>
              <FieldRef Name="FileLeafRef"/>
              <Value Type="Text">${q}</Value>
            </Contains>
            <Contains>
              <FieldRef Name="Title"/>
              <Value Type="Text">${q}</Value>
            </Contains>
          </Or>
          <Contains>
            <FieldRef Name="RegistrationNumber"/>
            <Value Type="Text">${q}</Value>
          </Contains>
        </Or>`);
    }

    // Status filter
    if (statusFilter && statusFilter !== "All") {
      conditions.push(`
        <Eq>
          <FieldRef Name="DocumentStatus"/>
          <Value Type="Choice">${this._escapeXml(statusFilter)}</Value>
        </Eq>`);
    }

    // Type filter
    if (typeFilter && typeFilter !== "All") {
      conditions.push(`
        <Eq>
          <FieldRef Name="DocumentType"/>
          <Value Type="Choice">${this._escapeXml(typeFilter)}</Value>
        </Eq>`);
    }

    if (conditions.length === 0) return "";
    if (conditions.length === 1) return conditions[0];

    // Wrap multiple conditions in nested <And> tags
    return conditions.reduce((acc, cond) =>
      acc ? `<And>${acc}${cond}</And>` : cond
    );
  }

  // ─── Private: Expand User Fields ─────────────────────────────────────────
  // odata=verbose returns user fields as deferred __deferred objects.
  // We batch-resolve them using the LoginName stored in the raw item.

  private async _expandUserFields(rawItems: any[], libraryTitle: string): Promise<any[]> {
    // For each item, try to get user titles from nested objects
    // In odata=verbose, user lookup fields come as { results: [] } or { __deferred }
    // We parse what we can without extra round-trips for performance.
    return rawItems.map(item => {
      // Author / Editor come as nested objects in verbose mode
      const getTitle = (field: any): string => {
        if (!field) return "";
        if (typeof field === "string") return field;
        if (field.Title) return field.Title;
        if (field.results && field.results[0]?.Title) return field.results[0].Title;
        return "";
      };

      return {
        ...item,
        _ownerTitle: getTitle(item.Owner) || getTitle(item.Author),
        _editorTitle: getTitle(item.Editor),
      };
    });
  }

  // ─── Private: Map Raw Item → IDocumentItem ────────────────────────────────

  private _mapToDocumentItem(item: any, libraryTitle: string): IDocumentItem {
    const fileLeafRef: string = item["FileLeafRef"] || "";
    const fileDirRef: string = item["FileDirRef"] || "";
    const isFolder: boolean = item["FSObjType"] === 1 || item["FSObjType"] === "1";
    const fileExtension = isFolder
      ? "Folder"
      : (fileLeafRef.split(".").pop()?.toUpperCase() || "Unknown");

    // ── Folder path calculation ──────────────────────────────────────────
    // FileDirRef looks like: /sites/mysite/LibraryTitle/Folder1/SubFolder2
    // We strip the site + library prefix to get just the folder hierarchy.
    const folderPath = this._extractFolderPath(fileDirRef, libraryTitle);
    const folderName = fileDirRef.split("/").pop() || "";

    // ── Absolute file URL ────────────────────────────────────────────────
    const siteOrigin = this.siteUrl.match(/^https?:\/\/[^/]+/)?.[0] || "";
    const fileRef = item["FileRef"] ? `${siteOrigin}${item["FileRef"]}` : "";

    return {
      id: item["ID"] || item["Id"] || 0,
      name: item["Title"] || fileLeafRef || "(No Title)",
      registrationNumber: item["RegistrationNumber"] || "",
      owner: item["_ownerTitle"] || "",
      status: item["DocumentStatus"] || "",
      type: item["DocumentType"] || fileExtension,
      fileName: fileLeafRef,
      folderName,
      folderPath,   // ← full nested path shown in results
      fileRef,
      serverRelativeUrl: item["FileRef"] || "",
      libraryTitle,
      created: item["Created"] || "",
      modified: item["Modified"] || "",
      modifiedBy: item["_editorTitle"] || "",
      fileSize: item["File_x0020_Size"] || 0,
      isFolder,
      contentType: item["ContentType"] || ""
    };
  }

  // ─── Private: Extract Human-Readable Folder Path ─────────────────────────
  // Input:  "/sites/mysite/Documents/Level1/Level2/Level3"
  // Output: "Level1 / Level2 / Level3"   (everything after the library root)

  private _extractFolderPath(fileDirRef: string, libraryTitle: string): string {
    if (!fileDirRef) return "";

    // Find the library title segment in the path and take everything after it
    const parts = fileDirRef.split("/");
    const libIndex = parts.findIndex(
      p => p.toLowerCase() === libraryTitle.toLowerCase()
    );

    if (libIndex === -1) {
      // Fallback: just return the last segment
      return parts[parts.length - 1] || "";
    }

    const subParts = parts.slice(libIndex + 1).filter(Boolean);
    return subParts.length > 0 ? subParts.join(" / ") : "(Root)";
  }

  // ─── Private: XML escape ─────────────────────────────────────────────────

  private _escapeXml(str: string): string {
    return str
      .replace(/&/g, "&amp;")
      .replace(/</g, "&lt;")
      .replace(/>/g, "&gt;")
      .replace(/"/g, "&quot;")
      .replace(/'/g, "&apos;");
  }
}
