// DocumentLibraryColumns.tsx  v2 — Enhanced Search UI
import * as React from "react";
import { DocumentLibraryService } from "../services/DocumentLibraryService";
import {
  IDocumentItem, ILibraryInfo, ISearchState
} from "./IDocumentItem";
import styles from "./DocumentLibraryColumns.module.scss";

interface Props {
  context: any;
  siteUrl?: string;
}

const FILE_ICONS: Record<string, string> = {
  pdf: "📄", doc: "📝", docx: "📝", xls: "📊", xlsx: "📊",
  ppt: "📋", pptx: "📋", txt: "📃", png: "🖼️", jpg: "🖼️",
  jpeg: "🖼️", gif: "🖼️", zip: "🗜️", msg: "✉️", mp4: "🎬",
  folder: "📁"
};

const STATUS_COLORS: Record<string, { bg: string; text: string; dot: string }> = {
  "draft":       { bg: "#f0f0f0", text: "#555", dot: "#aaa" },
  "in review":   { bg: "#fff8e1", text: "#795500", dot: "#ffc107" },
  "approved":    { bg: "#e8f5e9", text: "#2e7d32", dot: "#4caf50" },
  "published":   { bg: "#e3f2fd", text: "#0d47a1", dot: "#2196f3" },
  "archived":    { bg: "#f5f5f5", text: "#9e9e9e", dot: "#bdbdbd" },
  "rejected":    { bg: "#ffebee", text: "#c62828", dot: "#ef5350" },
};

function getStatusStyle(status: string) {
  return STATUS_COLORS[status?.toLowerCase()] || { bg: "#f0f4ff", text: "#3949ab", dot: "#5c6bc0" };
}

function getFileEmoji(item: IDocumentItem): string {
  if (item.isFolder) return FILE_ICONS.folder;
  const ext = item.fileName?.split(".").pop()?.toLowerCase() || "";
  return FILE_ICONS[ext] || "📄";
}

function formatSize(bytes: number): string {
  if (!bytes) return "";
  if (bytes < 1024) return `${bytes} B`;
  if (bytes < 1024 * 1024) return `${(bytes / 1024).toFixed(1)} KB`;
  return `${(bytes / (1024 * 1024)).toFixed(1)} MB`;
}

function formatDate(dateStr: string): string {
  if (!dateStr) return "";
  return new Date(dateStr).toLocaleDateString("en-GB", { day: "2-digit", month: "short", year: "numeric" });
}

function highlight(text: string, query: string): React.ReactNode {
  if (!query || !text) return text || "";
  const regex = new RegExp(`(${query.replace(/[.*+?^${}()|[\]\\]/g, "\\$&")})`, "gi");
  const parts = text.split(regex);
  return parts.map((part, i) =>
    regex.test(part)
      ? <mark key={i} className={styles.highlight}>{part}</mark>
      : part
  );
}

export default class DocumentLibraryColumns extends React.Component<Props, ISearchState> {
  private service: DocumentLibraryService;
  private searchDebounce: any = null;

  constructor(props: Props) {
    super(props);
    this.service = new DocumentLibraryService(props.context, props.siteUrl);
    this.state = {
      libraries: [], selectedLibrary: "",
      searchText: "", statusFilter: "All", typeFilter: "All",
      results: [], isLoadingLibraries: true, isSearching: false,
      hasSearched: false, errorMessage: "",
      statusOptions: [], typeOptions: [], expandedItemId: null
    };
  }

  public async componentDidMount(): Promise<void> {
    await this._loadLibraries();
  }

  private async _loadLibraries(): Promise<void> {
    this.setState({ isLoadingLibraries: true, errorMessage: "" });
    try {
      const libraries = await this.service.getAllDocumentLibraries();
      this.setState({ libraries, isLoadingLibraries: false });
    } catch (e) {
      this.setState({ isLoadingLibraries: false, errorMessage: "Could not load document libraries. " + e.message });
    }
  }

  private async _onLibraryChange(title: string): Promise<void> {
    this.setState({ selectedLibrary: title, statusOptions: [], typeOptions: [], results: [], hasSearched: false });
    if (!title) return;
    const [statuses, types] = await Promise.all([
      this.service.getChoiceValues(title, "DocumentStatus"),
      this.service.getChoiceValues(title, "DocumentType")
    ]);
    this.setState({ statusOptions: statuses, typeOptions: types });
  }

  private _onSearchInput(val: string): void {
    this.setState({ searchText: val });
    if (this.searchDebounce) clearTimeout(this.searchDebounce);
    if (val.trim().length >= 2) {
      this.searchDebounce = setTimeout(() => this._doSearch(), 400);
    }
  }

  private async _doSearch(): Promise<void> {
    const { selectedLibrary, searchText, statusFilter, typeFilter } = this.state;
    if (!selectedLibrary) { this.setState({ errorMessage: "Please select a document library first." }); return; }
    this.setState({ isSearching: true, errorMessage: "", hasSearched: false });
    try {
      const results = await this.service.searchItems(selectedLibrary, searchText, statusFilter, typeFilter);
      this.setState({ results, isSearching: false, hasSearched: true });
    } catch (e) {
      this.setState({ isSearching: false, errorMessage: "Search failed: " + e.message, hasSearched: true, results: [] });
    }
  }

  private _onClear(): void {
    if (this.searchDebounce) clearTimeout(this.searchDebounce);
    this.setState({
      searchText: "", statusFilter: "All", typeFilter: "All",
      results: [], hasSearched: false, errorMessage: "", expandedItemId: null
    });
  }

  private _toggleExpand(id: number): void {
    this.setState(prev => ({ expandedItemId: prev.expandedItemId === id ? null : id }));
  }

  // ─── Render ───────────────────────────────────────────────────────────────

  public render(): JSX.Element {
    const {
      libraries, selectedLibrary, searchText, statusFilter, typeFilter,
      results, isLoadingLibraries, isSearching, hasSearched, errorMessage,
      statusOptions, typeOptions, expandedItemId
    } = this.state;

    const hasFilters = searchText || statusFilter !== "All" || typeFilter !== "All";

    return (
      <div className={styles.wrap}>
        {/* ── Header ── */}
        <div className={styles.header}>
          <div className={styles.headerIcon}>🗂️</div>
          <div>
            <div className={styles.headerTitle}>Document Library Search</div>
            <div className={styles.headerSub}>Search, filter and explore documents across your site</div>
          </div>
        </div>

        {/* ── Search Panel ── */}
        <div className={styles.searchPanel}>

          {/* Library picker */}
          <div className={styles.fieldGroup}>
            <label className={styles.fieldLabel}>
              <span className={styles.labelIcon}>📚</span> Document Library
            </label>
            {isLoadingLibraries ? (
              <div className={styles.loadingPill}>⟳ Loading libraries…</div>
            ) : (
              <div className={styles.selectWrap}>
                <select
                  className={styles.select}
                  value={selectedLibrary}
                  onChange={e => this._onLibraryChange(e.target.value)}
                >
                  <option value="">— Choose a library —</option>
                  {libraries.map(lib => (
                    <option key={lib.id} value={lib.title}>
                      {lib.title} ({lib.itemCount} items)
                    </option>
                  ))}
                </select>
                <span className={styles.selectArrow}>▾</span>
              </div>
            )}
          </div>

          {/* Search row */}
          <div className={styles.searchRow}>
            <div className={styles.searchInputWrap}>
              <span className={styles.searchIcon}>🔍</span>
              <input
                className={styles.searchInput}
                type="text"
                placeholder="Search by name, registration number, title…"
                value={searchText}
                onChange={e => this._onSearchInput(e.target.value)}
                onKeyDown={e => e.key === "Enter" && this._doSearch()}
                disabled={!selectedLibrary}
              />
              {hasFilters && (
                <button className={styles.clearBtn} onClick={this._onClear.bind(this)} title="Clear all">
                  ✕ Clear
                </button>
              )}
            </div>
          </div>

          {/* Filter chips row */}
          <div className={styles.filterRow}>
            <div className={styles.filterGroup}>
              <span className={styles.filterLabel}>Status</span>
              <div className={styles.chips}>
                {["All", ...(statusOptions.length ? statusOptions : ["Draft","In Review","Approved","Published","Archived"])].map(s => (
                  <button
                    key={s}
                    className={`${styles.chip} ${statusFilter === s ? styles.chipActive : ""}`}
                    onClick={() => this.setState({ statusFilter: s }, () => hasSearched && this._doSearch())}
                    disabled={!selectedLibrary}
                  >{s}</button>
                ))}
              </div>
            </div>

            {typeOptions.length > 0 && (
              <div className={styles.filterGroup}>
                <span className={styles.filterLabel}>Type</span>
                <div className={styles.chips}>
                  {["All", ...typeOptions].map(t => (
                    <button
                      key={t}
                      className={`${styles.chip} ${typeFilter === t ? styles.chipActive : ""}`}
                      onClick={() => this.setState({ typeFilter: t }, () => hasSearched && this._doSearch())}
                    >{t}</button>
                  ))}
                </div>
              </div>
            )}

            <button
              className={styles.searchBtn}
              onClick={() => this._doSearch()}
              disabled={!selectedLibrary || isSearching}
            >
              {isSearching ? <span className={styles.spinner} /> : "Search"}
            </button>
          </div>
        </div>

        {/* ── Error ── */}
        {errorMessage && (
          <div className={styles.errorBar}>
            <span>⚠️ {errorMessage}</span>
            <button onClick={() => this.setState({ errorMessage: "" })}>✕</button>
          </div>
        )}

        {/* ── Results ── */}
        {isSearching && (
          <div className={styles.searching}>
            <div className={styles.searchingDots}><span /><span /><span /></div>
            <span>Searching documents…</span>
          </div>
        )}

        {hasSearched && !isSearching && (
          <div className={styles.resultsSection}>
            <div className={styles.resultsMeta}>
              <span className={styles.resultsCount}>
                {results.length === 0
                  ? "No documents found"
                  : `${results.length} document${results.length !== 1 ? "s" : ""} found`}
              </span>
              {results.length > 0 && (
                <span className={styles.resultsIn}>in <strong>{selectedLibrary}</strong></span>
              )}
            </div>

            {results.length > 0 && (
              <div className={styles.resultsList}>
                {results.map(item => {
                  const isExpanded = expandedItemId === item.id;
                  const statusStyle = getStatusStyle(item.status);
                  return (
                    <div key={item.id} className={`${styles.resultCard} ${isExpanded ? styles.resultCardExpanded : ""}`}>
                      {/* Card Header */}
                      <div className={styles.cardMain} onClick={() => this._toggleExpand(item.id)}>
                        <div className={styles.cardEmoji}>{getFileEmoji(item)}</div>
                        <div className={styles.cardBody}>
                          <div className={styles.cardTitleRow}>
                            {/* File link */}
                            {item.fileRef ? (
                              <a
                                href={item.fileRef}
                                target="_blank"
                                rel="noopener noreferrer"
                                className={styles.cardTitle}
                                onClick={e => e.stopPropagation()}
                              >
                                {highlight(item.name || item.fileName, searchText)}
                              </a>
                            ) : (
                              <span className={styles.cardTitle}>
                                {highlight(item.name || item.fileName, searchText)}
                              </span>
                            )}
                            {item.status && (
                              <span
                                className={styles.statusBadge}
                                style={{ background: statusStyle.bg, color: statusStyle.text }}
                              >
                                <span className={styles.statusDot} style={{ background: statusStyle.dot }} />
                                {item.status}
                              </span>
                            )}
                          </div>
                          {/* Quick meta row */}
                          <div className={styles.cardMeta}>
                            <span className={styles.metaChip} title="Item ID">
                              <span className={styles.metaLabel}>#ID</span> {item.id}
                            </span>
                            {item.registrationNumber && (
                              <span className={styles.metaChip} title="Registration Number">
                                <span className={styles.metaLabel}>Reg.</span>
                                {highlight(item.registrationNumber, searchText)}
                              </span>
                            )}
                            {item.owner && (
                              <span className={styles.metaChip}>
                                <span className={styles.metaLabel}>👤</span> {item.owner}
                              </span>
                            )}
                            {item.folderName && (
                              <span className={styles.metaChip}>
                                <span className={styles.metaLabel}>📁</span> {item.folderName}
                              </span>
                            )}
                            {item.type && item.type !== "Folder" && (
                              <span className={styles.metaChip}>
                                <span className={styles.metaLabel}>Type</span> {item.type}
                              </span>
                            )}
                          </div>
                        </div>
                        <div className={styles.cardActions}>
                          {item.fileRef && (
                            <a
                              href={item.fileRef}
                              target="_blank"
                              rel="noopener noreferrer"
                              className={styles.openBtn}
                              onClick={e => e.stopPropagation()}
                              title="Open file"
                            >Open ↗</a>
                          )}
                          <button
                            className={`${styles.expandBtn} ${isExpanded ? styles.expandBtnOpen : ""}`}
                            title={isExpanded ? "Collapse" : "View details"}
                          >▾</button>
                        </div>
                      </div>

                      {/* Expanded Details */}
                      {isExpanded && (
                        <div className={styles.cardDetails}>
                          <div className={styles.detailsGrid}>
                            <div className={styles.detailItem}>
                              <span className={styles.detailLabel}>Item ID</span>
                              <span className={styles.detailValue}>{item.id}</span>
                            </div>
                            <div className={styles.detailItem}>
                              <span className={styles.detailLabel}>File Name</span>
                              <span className={styles.detailValue}>{item.fileName || "—"}</span>
                            </div>
                            <div className={styles.detailItem}>
                              <span className={styles.detailLabel}>Registration No.</span>
                              <span className={styles.detailValue}>{item.registrationNumber || "—"}</span>
                            </div>
                            <div className={styles.detailItem}>
                              <span className={styles.detailLabel}>Owner</span>
                              <span className={styles.detailValue}>{item.owner || "—"}</span>
                            </div>
                            <div className={styles.detailItem}>
                              <span className={styles.detailLabel}>Status</span>
                              <span className={styles.detailValue}>
                                {item.status ? (
                                  <span className={styles.statusBadge} style={{ background: getStatusStyle(item.status).bg, color: getStatusStyle(item.status).text }}>
                                    <span className={styles.statusDot} style={{ background: getStatusStyle(item.status).dot }} />{item.status}
                                  </span>
                                ) : "—"}
                              </span>
                            </div>
                            <div className={styles.detailItem}>
                              <span className={styles.detailLabel}>Document Type</span>
                              <span className={styles.detailValue}>{item.type || "—"}</span>
                            </div>
                            <div className={styles.detailItem}>
                              <span className={styles.detailLabel}>Folder</span>
                              <span className={styles.detailValue}>{item.folderName || "(Root)"}</span>
                            </div>
                            <div className={styles.detailItem}>
                              <span className={styles.detailLabel}>Library</span>
                              <span className={styles.detailValue}>{item.libraryTitle}</span>
                            </div>
                            <div className={styles.detailItem}>
                              <span className={styles.detailLabel}>Modified</span>
                              <span className={styles.detailValue}>{formatDate(item.modified)}</span>
                            </div>
                            <div className={styles.detailItem}>
                              <span className={styles.detailLabel}>Modified By</span>
                              <span className={styles.detailValue}>{item.modifiedBy || "—"}</span>
                            </div>
                            <div className={styles.detailItem}>
                              <span className={styles.detailLabel}>Created</span>
                              <span className={styles.detailValue}>{formatDate(item.created)}</span>
                            </div>
                            <div className={styles.detailItem}>
                              <span className={styles.detailLabel}>File Size</span>
                              <span className={styles.detailValue}>{formatSize(item.fileSize) || "—"}</span>
                            </div>
                          </div>
                          {item.fileRef && (
                            <div className={styles.detailLink}>
                              <span className={styles.detailLabel}>File URL</span>
                              <a href={item.fileRef} target="_blank" rel="noopener noreferrer" className={styles.fileLink}>
                                🔗 {item.fileRef}
                              </a>
                            </div>
                          )}
                        </div>
                      )}
                    </div>
                  );
                })}
              </div>
            )}

            {results.length === 0 && !errorMessage && (
              <div className={styles.emptyState}>
                <div className={styles.emptyIcon}>🔍</div>
                <div className={styles.emptyTitle}>No documents found</div>
                <div className={styles.emptySub}>Try adjusting your search terms or filters</div>
                <button className={styles.clearFiltersBtn} onClick={this._onClear.bind(this)}>
                  Clear all filters
                </button>
              </div>
            )}
          </div>
        )}

        {/* ── Idle state ── */}
        {!hasSearched && !isSearching && !errorMessage && (
          <div className={styles.idleState}>
            <div className={styles.idleGrid}>
              {libraries.slice(0, 6).map(lib => (
                <button
                  key={lib.id}
                  className={styles.libraryCard}
                  onClick={() => {
                    this._onLibraryChange(lib.title);
                    this.setState({ selectedLibrary: lib.title });
                  }}
                >
                  <span className={styles.libIcon}>📚</span>
                  <span className={styles.libName}>{lib.title}</span>
                  <span className={styles.libCount}>{lib.itemCount} items</span>
                </button>
              ))}
            </div>
            {libraries.length === 0 && !isLoadingLibraries && (
              <p className={styles.idleHint}>Select a document library above to begin searching.</p>
            )}
          </div>
        )}
      </div>
    );
  }
}
