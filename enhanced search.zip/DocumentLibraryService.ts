// DocumentLibraryService.ts  (v2 - Enhanced)
import { WebPartContext } from "@microsoft/sp-webpart-base";
import { SPHttpClient, SPHttpClientResponse } from "@microsoft/sp-http";
import { IDocumentItem, ILibraryInfo } from "../components/IDocumentItem";

export class DocumentLibraryService {
  private context: WebPartContext;
  private siteUrl: string;

  private readonly SELECT_FIELDS = [
    "Id","FileLeafRef","FileRef","Title","RegistrationNumber",
    "Owner/Title","DocumentStatus","DocumentType","FileDirRef",
    "FSObjType","Created","Modified","Editor/Title",
    "File_x0020_Size","ContentType","Author/Title"
  ].join(",");

  private readonly EXPAND_FIELDS = "Owner,Editor,Author,File";

  constructor(context: WebPartContext, siteUrl?: string) {
    this.context = context;
    this.siteUrl = siteUrl || context.pageContext.web.absoluteUrl;
  }

  public async getAllDocumentLibraries(): Promise<ILibraryInfo[]> {
    try {
      const apiUrl = `${this.siteUrl}/_api/web/lists?$filter=BaseType eq 1 and Hidden eq false and IsCatalog eq false&$select=Id,Title,ItemCount,LastItemModifiedDate,DefaultViewUrl,Description&$orderby=Title asc`;
      const response: SPHttpClientResponse = await this.context.spHttpClient.get(apiUrl, SPHttpClient.configurations.v1, { headers: { Accept: "application/json;odata=nometadata" } });
      if (!response.ok) throw new Error(`HTTP ${response.status}`);
      const data = await response.json();
      return (data.value || []).map((lib: any): ILibraryInfo => ({
        id: lib.Id, title: lib.Title, itemCount: lib.ItemCount || 0,
        lastModified: lib.LastItemModifiedDate, defaultViewUrl: lib.DefaultViewUrl || "",
        description: lib.Description || ""
      }));
    } catch (error) { console.error("[Service] getAllDocumentLibraries:", error); throw error; }
  }

  public async searchItems(libraryTitle: string, searchText: string, statusFilter: string, typeFilter: string): Promise<IDocumentItem[]> {
    try {
      const filterParts: string[] = [];
      if (searchText && searchText.trim()) {
        const q = searchText.trim().replace(/'/g, "''");
        filterParts.push(`(substringof('${q}',FileLeafRef) or substringof('${q}',Title) or substringof('${q}',RegistrationNumber))`);
      }
      if (statusFilter && statusFilter !== "All") filterParts.push(`DocumentStatus eq '${statusFilter}'`);
      if (typeFilter && typeFilter !== "All") filterParts.push(`DocumentType eq '${typeFilter}'`);

      let apiUrl = `${this.siteUrl}/_api/web/lists/getByTitle('${encodeURIComponent(libraryTitle)}')/items?$select=${this.SELECT_FIELDS}&$expand=${this.EXPAND_FIELDS}&$top=200&$orderby=Modified desc`;
      if (filterParts.length) apiUrl += `&$filter=${filterParts.join(" and ")}`;

      const response: SPHttpClientResponse = await this.context.spHttpClient.get(apiUrl, SPHttpClient.configurations.v1, { headers: { Accept: "application/json;odata=nometadata" } });
      if (!response.ok) throw new Error(`HTTP ${response.status}`);
      const data = await response.json();
      return (data.value || []).map((item: any) => this._mapToDocumentItem(item, libraryTitle));
    } catch (error) { console.error("[Service] searchItems:", error); throw error; }
  }

  public async getChoiceValues(libraryTitle: string, fieldName: string): Promise<string[]> {
    try {
      const apiUrl = `${this.siteUrl}/_api/web/lists/getByTitle('${encodeURIComponent(libraryTitle)}')/fields/getByInternalNameOrTitle('${fieldName}')?$select=Choices`;
      const response: SPHttpClientResponse = await this.context.spHttpClient.get(apiUrl, SPHttpClient.configurations.v1, { headers: { Accept: "application/json;odata=nometadata" } });
      if (!response.ok) return [];
      const data = await response.json();
      return data.Choices || [];
    } catch { return []; }
  }

  private _mapToDocumentItem(item: any, libraryTitle: string): IDocumentItem {
    const fileLeafRef: string = item["FileLeafRef"] || "";
    const fileDirRef: string = item["FileDirRef"] || "";
    const isFolder: boolean = item["FSObjType"] === 1;
    const folderName = fileDirRef.split("/").pop() || "";
    const fileExtension = isFolder ? "Folder" : (fileLeafRef.split(".").pop()?.toUpperCase() || "Unknown");
    const siteOrigin = this.siteUrl.match(/^https?:\/\/[^/]+/)?.[0] || "";
    const fileUrl = item["FileRef"] ? `${siteOrigin}${item["FileRef"]}` : "";

    return {
      id: item["Id"] || 0, name: item["Title"] || fileLeafRef || "(No Title)",
      registrationNumber: item["RegistrationNumber"] || "",
      owner: item["Owner"]?.Title || item["Author"]?.Title || "",
      status: item["DocumentStatus"] || "", type: item["DocumentType"] || fileExtension,
      fileName: fileLeafRef, folderName, fileRef: fileUrl,
      serverRelativeUrl: item["FileRef"] || "", libraryTitle,
      created: item["Created"] || "", modified: item["Modified"] || "",
      modifiedBy: item["Editor"]?.Title || "", fileSize: item["File_x0020_Size"] || 0,
      isFolder, contentType: item["ContentType"] || ""
    };
  }
}
