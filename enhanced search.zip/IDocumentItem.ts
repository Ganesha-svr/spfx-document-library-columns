export interface IDocumentItem {
  id: number;
  name: string;
  registrationNumber: string;
  owner: string;
  status: string;
  type: string;
  fileName: string;
  folderName: string;
  fileRef: string;
  serverRelativeUrl: string;
  libraryTitle: string;
  created: string;
  modified: string;
  modifiedBy: string;
  fileSize: number;
  isFolder: boolean;
  contentType: string;
}

export interface ILibraryInfo {
  id: string;
  title: string;
  itemCount: number;
  lastModified: string;
  defaultViewUrl: string;
  description: string;
}

export interface ISearchState {
  libraries: ILibraryInfo[];
  selectedLibrary: string;
  searchText: string;
  statusFilter: string;
  typeFilter: string;
  results: IDocumentItem[];
  isLoadingLibraries: boolean;
  isSearching: boolean;
  hasSearched: boolean;
  errorMessage: string;
  statusOptions: string[];
  typeOptions: string[];
  expandedItemId: number | null;
}
