// DocumentLibraryService.ts  (v5 — Fixed 406 Accept Header)
// Columns: Title, Name, Product No, Brand No, Description, FileName
// Uses CAML POST with Scope="RecursiveAll" to search across all nested folders.
//
// FIX: Changed all GET requests from "odata=nometadata" to "odata=minimalmetadata"
// Some SharePoint tenants return HTTP 406 when odata=nometadata is used.
// "odata=minimalmetadata" is the safest and most widely accepted value.

import { WebPartContext } from "@microsoft/sp-webpart-base";
import { SPHttpClient, SPHttpClientResponse } from "@microsoft/sp-http";
import { IDocumentItem, ILibraryInfo } from "../components/IDocumentItem";

// Standard headers used for all GET requests
const GET_HEADERS = {
  "Accept": "application/json;odata=minimalmetadata",
  "Content-Type": "application/json;odata=minimalmetadata",
  "odata-version": "4.0"
};

// Headers for CAML POST requests — must use verbose for getItems endpoint
const POST_HEADERS = {
  "Accept": "application/json;odata=verbose",
  "Content-Type": "application/json;odata=verbose",
  "Prefer": "HonorNonIndexedQueriesWarningMayFailOnLargeList"
};

export class DocumentLibraryService {
  private context: WebPartContext;
  private siteUrl: string;

  // Internal column names for your library.
  // If SharePoint shows a field error, go to Library Settings → click the
  // column → check the URL "Field=" parameter for the exact internal name.
  private readonly CAML_FIELDS = [
    "ID",
    "FileLeafRef",      // File name
    "FileRef",          // Server-relative URL
    "Title",            // Title column
    "ProductNo",        // Product No  ← update if internal name differs
    "BrandNo",          // Brand No    ← update if internal name differs
    "Description0",     // Description ← try "Description" if this fails
    "FileDirRef",       // Folder path
    "FSObjType",        // 0=file, 1=folder
    "Created",
    "Modified",
    "Editor",           // Modified By
    "File_x0020_Size",  // File size in bytes
    "ContentType",
    "Author"            // Created By
  ];

  constructor(context: WebPartContext, siteUrl?: string) {
    this.context = context;
    this.siteUrl = (siteUrl || context.pageContext.web.absoluteUrl).replace(/\/$/, "");
  }

  // ─── List all Document Libraries in the site ─────────────────────────────

  public async getAllDocumentLibraries(): Promise<ILibraryInfo[]> {
    try {
      const apiUrl =
        `${this.siteUrl}/_api/web/lists` +
        `?$filter=BaseType eq 1 and Hidden eq false and IsCatalog eq false` +
        `&$select=Id,Title,ItemCount,LastItemModifiedDate,DefaultViewUrl,Description` +
        `&$orderby=Title asc`;

      const response: SPHttpClientResponse = await this.context.spHttpClient.get(
        apiUrl,
        SPHttpClient.configurations.v1,
        { headers: GET_HEADERS }
      );

      if (!response.ok) {
        const errText = await response.text();
        throw new Error(`HTTP ${response.status} — ${errText}`);
      }

      const data = await response.json();

      // minimalmetadata wraps results in value array
      const lists = data.value || data.d?.results || [];

      return lists.map((lib: any): ILibraryInfo => ({
        id: lib.Id,
        title: lib.Title,
        itemCount: lib.ItemCount || 0,
        lastModified: lib.LastItemModifiedDate,
        defaultViewUrl: lib.DefaultViewUrl || "",
        description: lib.Description || ""
      }));
    } catch (error) {
      console.error("[Service] getAllDocumentLibraries:", error);
      throw error;
    }
  }

  // ─── Search Items — CAML RecursiveAll ────────────────────────────────────
  // Scope="RecursiveAll" searches ALL nested subfolders at any depth.

  public async searchItems(
    libraryTitle: string,
    searchText: string,
    brandFilter: string
  ): Promise<IDocumentItem[]> {
    try {
      const whereClause = this._buildWhereClause(searchText, brandFilter);
      const viewFields = this.CAML_FIELDS.map(f => `<FieldRef Name="${f}"/>`).join("");

      const camlQuery = `
        <View Scope="RecursiveAll">
          <ViewFields>${viewFields}</ViewFields>
          <Query>
            <OrderBy>
              <FieldRef Name="Modified" Ascending="FALSE"/>
            </OrderBy>
            ${whereClause ? `<Where>${whereClause}</Where>` : ""}
          </Query>
          <RowLimit Paged="TRUE">500</RowLimit>
        </View>`;

      const apiUrl =
        `${this.siteUrl}/_api/web/lists/getByTitle('${encodeURIComponent(libraryTitle)}')/getItems`;

      const body = JSON.stringify({
        query: {
          __metadata: { type: "SP.CamlQuery" },
          ViewXml: camlQuery
        }
      });

      const response: SPHttpClientResponse = await this.context.spHttpClient.post(
        apiUrl,
        SPHttpClient.configurations.v1,
        { headers: POST_HEADERS, body }
      );

      if (!response.ok) {
        const errText = await response.text();
        throw new Error(`Search failed (HTTP ${response.status}): ${errText}`);
      }

      const data = await response.json();
      // odata=verbose wraps results under d.results
      const rawItems: any[] = data?.d?.results || [];

      return rawItems
        .map(item => this._mapToDocumentItem(item, libraryTitle))
        .filter(item => item.fileName !== "");

    } catch (error) {
      console.error("[Service] searchItems:", error);
      throw error;
    }
  }

  // ─── Get Brand No values for filter chips ────────────────────────────────

  public async getBrandOptions(libraryTitle: string): Promise<string[]> {
    // Try 1: Choice field — fastest, works if BrandNo is a Choice column
    try {
      const choiceUrl =
        `${this.siteUrl}/_api/web/lists/getByTitle('${encodeURIComponent(libraryTitle)}')` +
        `/fields/getByInternalNameOrTitle('BrandNo')?$select=Choices,FieldTypeKind`;

      const resp = await this.context.spHttpClient.get(
        choiceUrl,
        SPHttpClient.configurations.v1,
        { headers: GET_HEADERS }
      );

      if (resp.ok) {
        const d = await resp.json();
        const choices = d.Choices || d.d?.Choices;
        if (choices && choices.length > 0) return choices;
      }
    } catch { /* fall through */ }

    // Try 2: Scan first 200 items for distinct BrandNo text values
    try {
      const itemsUrl =
        `${this.siteUrl}/_api/web/lists/getByTitle('${encodeURIComponent(libraryTitle)}')` +
        `/items?$select=BrandNo&$top=200`;

      const resp = await this.context.spHttpClient.get(
        itemsUrl,
        SPHttpClient.configurations.v1,
        { headers: GET_HEADERS }
      );

      if (!resp.ok) return [];
      const d = await resp.json();
      const items = d.value || d.d?.results || [];

      const allBrands: string[] = items
        .map((i: any) => i.BrandNo)
        .filter((b: any) => b && b.toString().trim() !== "");

      const unique: string[] = allBrands.reduce((acc: string[], val: string) => {
        if (acc.indexOf(val) === -1) acc.push(val);
        return acc;
      }, []).sort();

      return unique;
    } catch {
      return [];
    }
  }

  // ─── Private: Build CAML <Where> clause ──────────────────────────────────

  private _buildWhereClause(searchText: string, brandFilter: string): string {
    const conditions: string[] = [];

    // Text search across all 5 columns — nested binary OR (CAML only allows 2 operands per Or)
    if (searchText && searchText.trim()) {
      const q = this._escapeXml(searchText.trim());
      conditions.push(`
        <Or>
          <Or>
            <Or>
              <Or>
                <Contains>
                  <FieldRef Name="FileLeafRef"/>
                  <Value Type="Text">${q}</Value>
                </Contains>
                <Contains>
                  <FieldRef Name="Title"/>
                  <Value Type="Text">${q}</Value>
                </Contains>
              </Or>
              <Contains>
                <FieldRef Name="ProductNo"/>
                <Value Type="Text">${q}</Value>
              </Contains>
            </Or>
            <Contains>
              <FieldRef Name="BrandNo"/>
              <Value Type="Text">${q}</Value>
            </Contains>
          </Or>
          <Contains>
            <FieldRef Name="Description0"/>
            <Value Type="Text">${q}</Value>
          </Contains>
        </Or>`);
    }

    // Brand No exact match filter
    if (brandFilter && brandFilter !== "All") {
      conditions.push(`
        <Eq>
          <FieldRef Name="BrandNo"/>
          <Value Type="Text">${this._escapeXml(brandFilter)}</Value>
        </Eq>`);
    }

    if (conditions.length === 0) return "";
    if (conditions.length === 1) return conditions[0];
    return conditions.reduce((acc, cond) => acc ? `<And>${acc}${cond}</And>` : cond);
  }

  // ─── Private: Map raw item → IDocumentItem ───────────────────────────────

  private _mapToDocumentItem(item: any, libraryTitle: string): IDocumentItem {
    const fileLeafRef: string = item["FileLeafRef"] || "";
    const fileDirRef: string  = item["FileDirRef"]  || "";
    const isFolder = item["FSObjType"] === 1 || item["FSObjType"] === "1";

    const folderPath = this._extractFolderPath(fileDirRef, libraryTitle);
    const folderName = fileDirRef.split("/").pop() || "";

    const siteOrigin = this.siteUrl.match(/^https?:\/\/[^/]+/)?.[0] || "";
    const fileRef = item["FileRef"] ? `${siteOrigin}${item["FileRef"]}` : "";

    const getTitle = (f: any): string => {
      if (!f) return "";
      if (typeof f === "string") return f;
      if (f.Title) return f.Title;
      if (f.results && f.results[0] && f.results[0].Title) return f.results[0].Title;
      return "";
    };

    return {
      id:          item["ID"]   || item["Id"] || 0,
      title:       item["Title"]        || "",
      name:        item["Title"]        || fileLeafRef || "(No Name)",
      productNo:   item["ProductNo"]    || "",
      brandNo:     item["BrandNo"]      || "",
      description: item["Description0"] || item["Description"] || "",
      fileName:    fileLeafRef,
      folderName,
      folderPath,
      fileRef,
      serverRelativeUrl: item["FileRef"] || "",
      libraryTitle,
      created:    item["Created"]  || "",
      modified:   item["Modified"] || "",
      modifiedBy: getTitle(item["Editor"]),
      fileSize:   item["File_x0020_Size"] || 0,
      isFolder,
      contentType: item["ContentType"] || ""
    };
  }

  // ─── Private: Build human-readable folder path ───────────────────────────
  // "/sites/mysite/Products/Brand A/2024" → "Brand A / 2024"

  private _extractFolderPath(fileDirRef: string, libraryTitle: string): string {
    if (!fileDirRef) return "";
    const parts = fileDirRef.split("/");
    const libIndex = parts.findIndex(
      p => p.toLowerCase() === libraryTitle.toLowerCase() ||
           decodeURIComponent(p).toLowerCase() === libraryTitle.toLowerCase()
    );
    if (libIndex === -1) return parts[parts.length - 1] || "";
    const subParts = parts.slice(libIndex + 1).filter(Boolean);
    return subParts.length > 0 ? subParts.join(" / ") : "(Root)";
  }

  // ─── Private: Escape XML special characters ──────────────────────────────

  private _escapeXml(str: string): string {
    return str
      .replace(/&/g, "&amp;")
      .replace(/</g, "&lt;")
      .replace(/>/g, "&gt;")
      .replace(/"/g, "&quot;")
      .replace(/'/g, "&apos;");
  }
}
