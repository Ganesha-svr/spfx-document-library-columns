// DocumentLibraryColumns.tsx  v8
// New features: Title→Folder link, File thumbnails, Document Set expansion
import * as React from "react";
import { DocumentLibraryService } from "../services/DocumentLibraryService";
import { IDocumentItem, ILibraryInfo, ISearchState } from "./IDocumentItem";
import styles from "./DocumentLibraryColumns.module.scss";

interface Props { context: any; siteUrl?: string; }

// File extension → Office UI icon colour
const EXT_COLORS: Record<string, string> = {
  pdf: "#d13438", doc: "#2b579a", docx: "#2b579a",
  xls: "#217346", xlsx: "#217346", ppt: "#b7472a", pptx: "#b7472a",
  png: "#8764b8", jpg: "#8764b8", jpeg: "#8764b8", gif: "#8764b8",
  zip: "#767676", msg: "#0078d4", mp4: "#e81123", txt: "#505050"
};

const EXT_LABELS: Record<string, string> = {
  pdf:"PDF", doc:"DOC", docx:"DOCX", xls:"XLS", xlsx:"XLSX",
  ppt:"PPT", pptx:"PPTX", png:"PNG", jpg:"JPG", jpeg:"JPG",
  gif:"GIF", zip:"ZIP", msg:"MSG", mp4:"MP4", txt:"TXT"
};

function getExt(fileName: string): string {
  return fileName?.split(".").pop()?.toLowerCase() || "";
}

function formatSize(bytes: number): string {
  if (!bytes) return "";
  if (bytes < 1024) return `${bytes} B`;
  if (bytes < 1048576) return `${(bytes/1024).toFixed(1)} KB`;
  return `${(bytes/1048576).toFixed(1)} MB`;
}

function formatDate(d: string): string {
  if (!d) return "";
  return new Date(d).toLocaleDateString("en-GB", { day:"2-digit", month:"short", year:"numeric" });
}

function highlight(text: string, query: string): React.ReactNode {
  if (!query || !text) return text || "";
  const safe  = query.replace(/[.*+?^${}()|[\]\\]/g, "\\$&");
  const regex = new RegExp(`(${safe})`, "gi");
  return text.split(regex).map((p, i) =>
    regex.test(p) ? <mark key={i} className={styles.highlight}>{p}</mark> : p
  );
}

// ── Thumbnail / File Badge component ──────────────────────────────────────────
function FileBadge({ item }: { item: IDocumentItem }): JSX.Element {
  const ext   = getExt(item.fileName);
  const color = EXT_COLORS[ext] || "#767676";
  const label = EXT_LABELS[ext] || ext.toUpperCase() || "FILE";

  const [thumbError, setThumbError] = React.useState(false);
  const showThumb = item.thumbnailUrl && !thumbError;

  if (item.isDocumentSet) {
    return (
      <div className={styles.fileBadge} style={{ background: "#0078d4" }}>
        <span className={styles.fileBadgeIcon}>📂</span>
        <span className={styles.fileBadgeLabel}>SET</span>
      </div>
    );
  }

  if (showThumb) {
    return (
      <div className={styles.thumbWrap}>
        <img
          src={item.thumbnailUrl}
          className={styles.thumb}
          alt={item.fileName}
          onError={() => setThumbError(true)}
        />
        <span className={styles.thumbBadge} style={{ background: color }}>{label}</span>
      </div>
    );
  }

  return (
    <div className={styles.fileBadge} style={{ background: color }}>
      <span className={styles.fileBadgeIcon}>
        {item.isFolder ? "📁" : ext === "pdf" ? "📄" : ext === "xlsx" || ext === "xls" ? "📊"
          : ext === "docx" || ext === "doc" ? "📝" : ext === "pptx" || ext === "ppt" ? "📋"
          : ext.match(/^(png|jpg|jpeg|gif)$/) ? "🖼️" : "📄"}
      </span>
      <span className={styles.fileBadgeLabel}>{label}</span>
    </div>
  );
}

// ── Document Set children list ─────────────────────────────────────────────────
function DocSetChildren({ children, searchText }: { children: IDocumentItem[]; searchText: string }): JSX.Element {
  if (!children || children.length === 0) {
    return <div className={styles.docSetEmpty}>No files found inside this Document Set.</div>;
  }
  return (
    <div className={styles.docSetChildren}>
      <div className={styles.docSetChildrenHeader}>
        📎 {children.length} file{children.length !== 1 ? "s" : ""} in this Document Set
      </div>
      {children.map(child => {
        const ext   = getExt(child.fileName);
        const color = EXT_COLORS[ext] || "#767676";
        return (
          <div key={child.id} className={styles.docSetChild}>
            <div className={styles.docSetChildBadge} style={{ background: color }}>
              {EXT_LABELS[ext] || "FILE"}
            </div>
            <div className={styles.docSetChildInfo}>
              <a href={child.fileRef} target="_blank" rel="noopener noreferrer"
                className={styles.docSetChildName}>
                {highlight(child.fileName, searchText)}
              </a>
              <span className={styles.docSetChildMeta}>
                {formatSize(child.fileSize)} · {formatDate(child.modified)}
                {child.modifiedBy && ` · ${child.modifiedBy}`}
              </span>
            </div>
            <a href={child.fileRef} target="_blank" rel="noopener noreferrer"
              className={styles.docSetChildOpen} title="Open file">↗</a>
          </div>
        );
      })}
    </div>
  );
}

// ── Main Component ─────────────────────────────────────────────────────────────
export default class DocumentLibraryColumns extends React.Component<Props, ISearchState> {
  private service: DocumentLibraryService;
  private debounce: any = null;

  constructor(props: Props) {
    super(props);
    this.service = new DocumentLibraryService(props.context, props.siteUrl);
    this.state = {
      libraries: [], selectedLibrary: "", searchText: "", brandFilter: "All",
      results: [], isLoadingLibraries: true, isSearching: false,
      hasSearched: false, errorMessage: "", brandOptions: [],
      expandedItemId: null, loadingChildrenId: null
    };
  }

  public async componentDidMount(): Promise<void> {
    try {
      const libraries = await this.service.getAllDocumentLibraries();
      this.setState({ libraries, isLoadingLibraries: false });
    } catch (e) {
      this.setState({ isLoadingLibraries: false, errorMessage: "Could not load libraries: " + e.message });
    }
  }

  private async _onLibraryChange(title: string): Promise<void> {
    this.setState({ selectedLibrary: title, brandOptions: [], results: [], hasSearched: false, errorMessage: "" });
    if (!title) return;
    const brands = await this.service.getBrandOptions(title);
    this.setState({ brandOptions: brands });
  }

  private _onSearchInput(val: string): void {
    this.setState({ searchText: val });
    if (this.debounce) clearTimeout(this.debounce);
    if (val.trim().length >= 2) this.debounce = setTimeout(() => this._doSearch(), 400);
  }

  private async _doSearch(): Promise<void> {
    const { selectedLibrary, searchText, brandFilter } = this.state;
    if (!selectedLibrary) { this.setState({ errorMessage: "Please select a library first." }); return; }
    this.setState({ isSearching: true, errorMessage: "", hasSearched: false });
    try {
      const results = await this.service.searchItems(selectedLibrary, searchText, brandFilter);
      this.setState({ results, isSearching: false, hasSearched: true });
    } catch (e) {
      this.setState({ isSearching: false, hasSearched: true, results: [], errorMessage: "Search failed: " + e.message });
    }
  }

  private _onClear(): void {
    if (this.debounce) clearTimeout(this.debounce);
    this.setState({ searchText: "", brandFilter: "All", results: [], hasSearched: false, errorMessage: "", expandedItemId: null, loadingChildrenId: null });
  }

  private async _toggleExpand(item: IDocumentItem): Promise<void> {
    const { expandedItemId, selectedLibrary } = this.state;
    if (expandedItemId === item.id) {
      this.setState({ expandedItemId: null });
      return;
    }

    // If it's a Document Set, load children first
    if (item.isDocumentSet && (!item.children || item.children.length === 0)) {
      this.setState({ loadingChildrenId: item.id });
      const children = await this.service.getDocumentSetChildren(
        selectedLibrary, item.serverRelativeUrl
      );
      // Inject children into result list
      this.setState(prev => ({
        results: prev.results.map(r => r.id === item.id ? { ...r, children } : r),
        loadingChildrenId: null,
        expandedItemId: item.id
      }));
    } else {
      this.setState({ expandedItemId: item.id });
    }
  }

  public render(): JSX.Element {
    const {
      libraries, selectedLibrary, searchText, brandFilter,
      results, isLoadingLibraries, isSearching, hasSearched,
      errorMessage, brandOptions, expandedItemId, loadingChildrenId
    } = this.state;

    const hasFilters = !!(searchText || brandFilter !== "All");

    return (
      <div className={styles.wrap}>

        {/* Header */}
        <div className={styles.header}>
          <div className={styles.headerIcon}>📦</div>
          <div>
            <div className={styles.headerTitle}>Product Document Search</div>
            <div className={styles.headerSub}>Search Title, Name, Product No, Brand No, Description — all folders</div>
          </div>
        </div>

        {/* Search Panel */}
        <div className={styles.searchPanel}>

          {/* Library picker */}
          <div className={styles.fieldGroup}>
            <label className={styles.fieldLabel}>
              <span className={styles.labelIcon}>📚</span> Document Library
            </label>
            {isLoadingLibraries ? (
              <div className={styles.loadingPill}>⟳ Loading libraries…</div>
            ) : (
              <div className={styles.selectWrap}>
                <select className={styles.select} value={selectedLibrary}
                  onChange={e => this._onLibraryChange(e.target.value)}>
                  <option value="">— Choose a library —</option>
                  {libraries.map(lib => (
                    <option key={lib.id} value={lib.title}>{lib.title} ({lib.itemCount} items)</option>
                  ))}
                </select>
                <span className={styles.selectArrow}>▾</span>
              </div>
            )}
          </div>

          {/* Search input */}
          <div className={styles.searchRow}>
            <div className={styles.searchInputWrap}>
              <span className={styles.searchIcon}>🔍</span>
              <input className={styles.searchInput} type="text"
                placeholder="Search by Title, Name, Product No, Brand No, Description…"
                value={searchText}
                onChange={e => this._onSearchInput(e.target.value)}
                onKeyDown={e => e.key === "Enter" && this._doSearch()}
                disabled={!selectedLibrary}
              />
              {hasFilters && (
                <button className={styles.clearBtn} onClick={this._onClear.bind(this)}>✕ Clear</button>
              )}
            </div>
            <button className={styles.searchBtn} onClick={() => this._doSearch()} disabled={!selectedLibrary || isSearching}>
              {isSearching ? "Searching…" : "Search"}
            </button>
          </div>

          {/* Brand filter chips */}
          {brandOptions.length > 0 && (
            <div className={styles.filterRow}>
              <span className={styles.filterLabel}>Brand No:</span>
              <div className={styles.chipGroup}>
                {["All", ...brandOptions].map(b => (
                  <button key={b}
                    className={`${styles.chip} ${brandFilter === b ? styles.chipActive : ""}`}
                    onClick={() => { this.setState({ brandFilter: b }, () => { if (searchText) this._doSearch(); }); }}>
                    {b}
                  </button>
                ))}
              </div>
            </div>
          )}
        </div>

        {/* Error */}
        {errorMessage && (
          <div className={styles.errorBanner}>
            <span className={styles.errorIcon}>⚠️</span>
            <span>{errorMessage}</span>
          </div>
        )}

        {/* Loading */}
        {isSearching && (
          <div className={styles.loadingState}>
            <div className={styles.spinner}></div>
            <span>Searching all folders…</span>
          </div>
        )}

        {/* Results */}
        {hasSearched && !isSearching && (
          <div className={styles.resultsSection}>
            {results.length > 0 && (
              <div className={styles.resultsHeader}>
                <span className={styles.resultCount}>{results.length} result{results.length !== 1 ? "s" : ""}</span>
                <span className={styles.recursiveBadge}>🔁 All folders searched</span>
              </div>
            )}

            {results.length > 0 && (
              <div className={styles.resultsList}>
                {results.map(item => {
                  const isExpanded = expandedItemId === item.id;
                  const isLoadingChildren = loadingChildrenId === item.id;
                  const ext = getExt(item.fileName);

                  return (
                    <div key={item.id}
                      className={`${styles.card} ${isExpanded ? styles.cardExpanded : ""} ${item.isDocumentSet ? styles.cardDocSet : ""}`}
                      onClick={() => this._toggleExpand(item)}>

                      {/* Card main row */}
                      <div className={styles.cardMain}>

                        {/* Thumbnail / File Badge */}
                        <div className={styles.cardThumb}>
                          <FileBadge item={item} />
                        </div>

                        {/* Card content */}
                        <div className={styles.cardContent}>

                          {/* Title row */}
                          <div className={styles.cardTitleRow}>
                            {/* Title → links to folder */}
                            {item.folderUrl ? (
                              <a href={item.folderUrl} target="_blank" rel="noopener noreferrer"
                                className={`${styles.cardTitle} ${styles.cardTitleLink}`}
                                onClick={e => e.stopPropagation()}
                                title={`Open folder: ${item.folderPath || item.libraryTitle}`}>
                                {highlight(item.name || item.fileName, searchText)}
                                <span className={styles.folderLinkIcon}>📁</span>
                              </a>
                            ) : (
                              <span className={styles.cardTitle}>
                                {highlight(item.name || item.fileName, searchText)}
                              </span>
                            )}

                            {/* Document Set badge */}
                            {item.isDocumentSet && (
                              <span className={styles.docSetBadge}>Document Set</span>
                            )}

                            {/* Content type badge */}
                            {!item.isDocumentSet && item.contentType && item.contentType !== "Document" && (
                              <span className={styles.contentTypeBadge}>{item.contentType}</span>
                            )}
                          </div>

                          {/* Meta chips */}
                          <div className={styles.metaRow}>
                            {item.id > 0 && (
                              <span className={styles.metaChip}>#ID {item.id}</span>
                            )}
                            {item.productNo && (
                              <span className={styles.metaChipGreen} title="Product No">
                                🏷️ {highlight(item.productNo, searchText)}
                              </span>
                            )}
                            {item.brandNo && (
                              <span className={styles.metaChipOrange} title="Brand No">
                                🔖 {highlight(item.brandNo, searchText)}
                              </span>
                            )}
                            {item.folderPath && item.folderPath !== "(Root)" && (
                              <a href={item.folderUrl} target="_blank" rel="noopener noreferrer"
                                className={`${styles.metaChip} ${styles.folderChip}`}
                                onClick={e => e.stopPropagation()}
                                title={`Open folder: ${item.folderPath}`}>
                                📁 {item.folderPath}
                              </a>
                            )}
                            {!item.isDocumentSet && item.fileSize > 0 && (
                              <span className={styles.metaChip}>{formatSize(item.fileSize)}</span>
                            )}
                            {item.isDocumentSet && item.children && (
                              <span className={styles.metaChip}>📎 {item.children.length} files</span>
                            )}
                          </div>

                          {/* Description */}
                          {item.description && (
                            <div className={styles.descPreview}>
                              {highlight(item.description.length > 120 ? item.description.slice(0,120)+"…" : item.description, searchText)}
                            </div>
                          )}
                        </div>

                        {/* Actions */}
                        <div className={styles.cardActions}>
                          {item.isDocumentSet ? (
                            <a href={item.documentSetUrl} target="_blank" rel="noopener noreferrer"
                              className={styles.openBtn} onClick={e => e.stopPropagation()} title="Open Document Set">
                              Open ↗
                            </a>
                          ) : item.fileRef ? (
                            <a href={item.fileRef} target="_blank" rel="noopener noreferrer"
                              className={styles.openBtn} onClick={e => e.stopPropagation()} title="Open file">
                              Open ↗
                            </a>
                          ) : null}
                          <button
                            className={`${styles.expandBtn} ${isExpanded ? styles.expandBtnOpen : ""}`}
                            title={isExpanded ? "Collapse" : item.isDocumentSet ? "View files in Document Set" : "View details"}>
                            {isLoadingChildren ? "⟳" : "▾"}
                          </button>
                        </div>
                      </div>

                      {/* Expanded panel */}
                      {isExpanded && (
                        <div className={styles.cardDetails} onClick={e => e.stopPropagation()}>

                          {/* Document Set — show children */}
                          {item.isDocumentSet ? (
                            isLoadingChildren ? (
                              <div className={styles.loadingState}>
                                <div className={styles.spinner}></div>
                                <span>Loading files…</span>
                              </div>
                            ) : (
                              <DocSetChildren children={item.children || []} searchText={searchText} />
                            )
                          ) : (
                            /* Regular file — show full details */
                            <div className={styles.detailsGrid}>
                              <div className={styles.detailItem}>
                                <span className={styles.detailLabel}>Title</span>
                                <span className={styles.detailValue}>{item.title || "—"}</span>
                              </div>
                              <div className={styles.detailItem}>
                                <span className={styles.detailLabel}>File Name</span>
                                <span className={styles.detailValue}>{item.fileName || "—"}</span>
                              </div>
                              <div className={styles.detailItem}>
                                <span className={styles.detailLabel}>Product No</span>
                                <span className={`${styles.detailValue} ${styles.monoValue}`}>{item.productNo || "—"}</span>
                              </div>
                              <div className={styles.detailItem}>
                                <span className={styles.detailLabel}>Brand No</span>
                                <span className={`${styles.detailValue} ${styles.monoValue}`}>{item.brandNo || "—"}</span>
                              </div>
                              <div className={styles.detailItem}>
                                <span className={styles.detailLabel}>Modified</span>
                                <span className={styles.detailValue}>{formatDate(item.modified)}</span>
                              </div>
                              <div className={styles.detailItem}>
                                <span className={styles.detailLabel}>Modified By</span>
                                <span className={styles.detailValue}>{item.modifiedBy || "—"}</span>
                              </div>
                              <div className={styles.detailItem}>
                                <span className={styles.detailLabel}>Created</span>
                                <span className={styles.detailValue}>{formatDate(item.created)}</span>
                              </div>
                              <div className={styles.detailItem}>
                                <span className={styles.detailLabel}>File Size</span>
                                <span className={styles.detailValue}>{formatSize(item.fileSize) || "—"}</span>
                              </div>
                              <div className={`${styles.detailItem} ${styles.detailItemWide}`}>
                                <span className={styles.detailLabel}>📁 Folder Path</span>
                                <a href={item.folderUrl} target="_blank" rel="noopener noreferrer"
                                  className={styles.folderPathLink}>
                                  {item.libraryTitle}
                                  {item.folderPath && item.folderPath !== "(Root)" &&
                                    item.folderPath.split(" / ").map((seg, i) => (
                                      <span key={i}> › {seg}</span>
                                    ))
                                  }
                                  <span className={styles.folderLinkIcon}>↗</span>
                                </a>
                              </div>
                              {item.description && (
                                <div className={`${styles.detailItem} ${styles.detailItemWide}`}>
                                  <span className={styles.detailLabel}>Description</span>
                                  <span className={styles.detailValue}>{item.description}</span>
                                </div>
                              )}
                              <div className={`${styles.detailItem} ${styles.detailItemWide}`}>
                                <span className={styles.detailLabel}>🔗 File URL</span>
                                <a href={item.fileRef} target="_blank" rel="noopener noreferrer"
                                  className={styles.fileLink}>{item.fileRef}</a>
                              </div>
                            </div>
                          )}
                        </div>
                      )}
                    </div>
                  );
                })}
              </div>
            )}

            {results.length === 0 && !errorMessage && (
              <div className={styles.emptyState}>
                <div className={styles.emptyIcon}>🔍</div>
                <div className={styles.emptyTitle}>No documents found</div>
                <div className={styles.emptySub}>Try adjusting your search or Brand No filter</div>
                <button className={styles.clearFiltersBtn} onClick={this._onClear.bind(this)}>Clear filters</button>
              </div>
            )}
          </div>
        )}

        {/* Idle state */}
        {!hasSearched && !isSearching && !errorMessage && (
          <div className={styles.idleState}>
            <div className={styles.idleGrid}>
              {libraries.slice(0,6).map(lib => (
                <button key={lib.id} className={styles.libraryCard}
                  onClick={() => { this._onLibraryChange(lib.title); this.setState({ selectedLibrary: lib.title }); }}>
                  <span className={styles.libIcon}>📚</span>
                  <span className={styles.libName}>{lib.title}</span>
                  <span className={styles.libCount}>{lib.itemCount} items</span>
                </button>
              ))}
            </div>
          </div>
        )}

      </div>
    );
  }
}
