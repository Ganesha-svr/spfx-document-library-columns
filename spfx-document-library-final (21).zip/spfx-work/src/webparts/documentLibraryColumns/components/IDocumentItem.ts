export interface IDocumentItem {
  id: number;
  title: string;
  name: string;
  productNo: string;
  brandNo: string;
  description: string;
  fileName: string;
  folderName: string;
  folderPath: string;
  folderUrl: string;          // NEW: absolute URL to the folder containing this file
  fileRef: string;
  serverRelativeUrl: string;
  libraryTitle: string;
  created: string;
  modified: string;
  modifiedBy: string;
  fileSize: number;
  isFolder: boolean;
  isDocumentSet: boolean;     // NEW: true if this item is a Document Set
  documentSetUrl: string;     // NEW: URL to open the Document Set welcome page
  contentType: string;
  thumbnailUrl: string;       // NEW: SharePoint thumbnail URL for file previews
  children?: IDocumentItem[]; // NEW: files inside a Document Set (populated on expand)
}

export interface ILibraryInfo {
  id: string;
  title: string;
  itemCount: number;
  lastModified: string;
  defaultViewUrl: string;
  description: string;
}

export interface ISearchState {
  libraries: ILibraryInfo[];
  selectedLibrary: string;
  searchText: string;
  brandFilter: string;
  results: IDocumentItem[];
  isLoadingLibraries: boolean;
  isSearching: boolean;
  hasSearched: boolean;
  errorMessage: string;
  brandOptions: string[];
  expandedItemId: number | null;
  loadingChildrenId: number | null;  // NEW: tracks which Document Set is loading
}
