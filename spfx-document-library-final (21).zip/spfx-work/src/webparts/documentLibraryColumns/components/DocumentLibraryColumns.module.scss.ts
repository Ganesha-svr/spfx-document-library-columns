// DocumentLibraryColumns.module.scss.ts  (v8 — complete type declarations)
// All class names declared inside a single "declare const styles" block.
// This is the correct pattern for SPFx SCSS modules — NOT "export const name: string;"

declare const styles: {
  // ── Layout ──
  readonly wrap: string;
  // ── Header ──
  readonly header: string;
  readonly headerIcon: string;
  readonly headerTitle: string;
  readonly headerSub: string;
  // ── Search Panel ──
  readonly searchPanel: string;
  readonly fieldGroup: string;
  readonly fieldLabel: string;
  readonly labelIcon: string;
  readonly selectWrap: string;
  readonly select: string;
  readonly selectArrow: string;
  readonly searchRow: string;
  readonly searchInputWrap: string;
  readonly searchIcon: string;
  readonly searchInput: string;
  readonly clearBtn: string;
  readonly filterRow: string;
  readonly filterGroup: string;
  readonly filterLabel: string;
  readonly chipGroup: string;
  readonly chips: string;
  readonly chip: string;
  readonly chipActive: string;
  readonly searchBtn: string;
  // ── Loading / Error ──
  readonly spinner: string;
  readonly loadingPill: string;
  readonly loadingState: string;
  readonly errorBar: string;
  readonly errorBanner: string;
  readonly errorIcon: string;
  readonly searching: string;
  readonly searchingDots: string;
  // ── Results ──
  readonly resultsSection: string;
  readonly resultsHeader: string;
  readonly resultsMeta: string;
  readonly resultCount: string;
  readonly resultsCount: string;
  readonly resultsIn: string;
  readonly recursiveBadge: string;
  readonly resultsList: string;
  readonly resultCard: string;
  readonly resultCardExpanded: string;
  // ── Card ──
  readonly card: string;
  readonly cardExpanded: string;
  readonly cardDocSet: string;
  readonly cardMain: string;
  readonly cardThumb: string;
  readonly cardEmoji: string;
  readonly cardBody: string;
  readonly cardContent: string;
  readonly cardTitleRow: string;
  readonly cardTitle: string;
  readonly cardTitleLink: string;
  readonly cardMeta: string;
  readonly metaRow: string;
  readonly metaChip: string;
  readonly metaChipGreen: string;
  readonly metaChipOrange: string;
  readonly metaLabel: string;
  readonly descPreview: string;
  readonly brandBadge: string;
  readonly cardActions: string;
  readonly openBtn: string;
  readonly expandBtn: string;
  readonly expandBtnOpen: string;
  readonly cardDetails: string;
  // ── File Badge / Thumbnail ──
  readonly fileBadge: string;
  readonly fileBadgeIcon: string;
  readonly fileBadgeLabel: string;
  readonly thumbWrap: string;
  readonly thumb: string;
  readonly thumbBadge: string;
  // ── Folder ──
  readonly folderLinkIcon: string;
  readonly folderChip: string;
  readonly folderPathLink: string;
  readonly folderPathInline: string;
  readonly folderBreadcrumb: string;
  readonly folderCrumb: string;
  readonly folderCrumbWrap: string;
  readonly folderSep: string;
  // ── Document Set ──
  readonly docSetBadge: string;
  readonly docSetChildren: string;
  readonly docSetChildrenHeader: string;
  readonly docSetChild: string;
  readonly docSetChildBadge: string;
  readonly docSetChildInfo: string;
  readonly docSetChildName: string;
  readonly docSetChildMeta: string;
  readonly docSetChildOpen: string;
  readonly docSetEmpty: string;
  // ── Content Type ──
  readonly contentTypeBadge: string;
  // ── Details Panel ──
  readonly detailsGrid: string;
  readonly detailItem: string;
  readonly detailItemWide: string;
  readonly detailLabel: string;
  readonly detailValue: string;
  readonly monoValue: string;
  readonly detailLink: string;
  readonly fileLink: string;
  // ── Highlight ──
  readonly highlight: string;
  // ── Empty / Idle ──
  readonly emptyState: string;
  readonly emptyIcon: string;
  readonly emptyTitle: string;
  readonly emptySub: string;
  readonly clearFiltersBtn: string;
  readonly idleState: string;
  readonly idleGrid: string;
  readonly libraryCard: string;
  readonly libIcon: string;
  readonly libName: string;
  readonly libCount: string;
  readonly idleHint: string;
};

export default styles;
