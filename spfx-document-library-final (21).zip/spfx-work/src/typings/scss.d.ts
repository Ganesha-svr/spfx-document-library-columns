// typings/scss.d.ts
// Global wildcard declaration for CSS/SCSS modules.
// This is the fallback if a specific .module.scss.ts file is missing.

declare module "*.module.scss" {
  const styles: { readonly [className: string]: string };
  export default styles;
}

declare module "*.module.css" {
  const styles: { readonly [className: string]: string };
  export default styles;
}
