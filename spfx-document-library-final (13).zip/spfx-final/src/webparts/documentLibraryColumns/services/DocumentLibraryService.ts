// DocumentLibraryService.ts  (v8 — Folder Link + Thumbnails + Document Sets)

import { WebPartContext } from "@microsoft/sp-webpart-base";
import { SPHttpClient, SPHttpClientResponse } from "@microsoft/sp-http";
import { IDocumentItem, ILibraryInfo } from "../components/IDocumentItem";

const HEADERS = {
  "Accept": "application/json;odata=verbose",
  "Content-Type": "application/json;odata=verbose",
  "Prefer": "HonorNonIndexedQueriesWarningMayFailOnLargeList"
};

const BUILTIN_FIELDS = [
  "ID", "FileLeafRef", "FileRef", "Title",
  "FileDirRef", "FSObjType", "Created", "Modified",
  "Editor", "File_x0020_Size", "ContentType", "Author",
  "HTML_x0020_File_x0020_Type"   // needed to detect Document Sets
];

const CUSTOM_FIELD_CANDIDATES: { [key: string]: string[] } = {
  productNo:   ["ProductNo", "Product_x0020_No", "ProductNumber", "Product_No"],
  brandNo:     ["BrandNo",   "Brand_x0020_No",   "BrandNumber",   "Brand_No"],
  description: ["Description0", "Description", "Description1", "Desc"]
};

export class DocumentLibraryService {
  private context: WebPartContext;
  private siteUrl: string;
  private siteOrigin: string;
  private fieldCache: { [lib: string]: { [key: string]: string } } = {};

  constructor(context: WebPartContext, siteUrl?: string) {
    this.context = context;
    this.siteUrl = (siteUrl || context.pageContext.web.absoluteUrl).replace(/\/$/, "");
    this.siteOrigin = this.siteUrl.match(/^https?:\/\/[^/]+/)?.[0] || "";
  }

  // ─── Discover real internal field names ───────────────────────────────────

  private async _discoverFields(libraryTitle: string): Promise<{ [key: string]: string }> {
    if (this.fieldCache[libraryTitle]) return this.fieldCache[libraryTitle];
    const result: { [key: string]: string } = {};
    try {
      const url =
        `${this.siteUrl}/_api/web/lists/getByTitle('${encodeURIComponent(libraryTitle)}')` +
        `/fields?$select=InternalName&$filter=Hidden eq false`;
      const resp = await this.context.spHttpClient.get(
        url, SPHttpClient.configurations.v1, { headers: HEADERS }
      );
      if (resp.ok) {
        const data = await resp.json();
        const names: string[] = (data?.d?.results || []).map((f: any) => f.InternalName as string);
        for (const key of Object.keys(CUSTOM_FIELD_CANDIDATES)) {
          const found = CUSTOM_FIELD_CANDIDATES[key].find(c =>
            names.some(n => n.toLowerCase() === c.toLowerCase())
          );
          if (found) {
            result[key] = names.find(n => n.toLowerCase() === found.toLowerCase()) || found;
          }
        }
      }
    } catch (e) {
      console.warn("[Service] Field discovery failed:", e);
    }
    this.fieldCache[libraryTitle] = result;
    return result;
  }

  // ─── Get thumbnail URL for a file ─────────────────────────────────────────
  // Uses SharePoint's /_layouts/15/getpreview.ashx endpoint

  public getThumbnailUrl(serverRelativeUrl: string, fileExt: string): string {
    if (!serverRelativeUrl) return "";
    const imageExts = ["png", "jpg", "jpeg", "gif", "bmp", "webp", "svg"];
    const officeExts = ["pdf", "doc", "docx", "xls", "xlsx", "ppt", "pptx"];
    const ext = fileExt.toLowerCase();
    if (imageExts.indexOf(ext) !== -1 || officeExts.indexOf(ext) !== -1) {
      return `${this.siteOrigin}/_layouts/15/getpreview.ashx?path=${encodeURIComponent(serverRelativeUrl)}&resolution=0`;
    }
    return ""; // No thumbnail for zip, msg, etc.
  }

  // ─── Get folder URL from FileDirRef ───────────────────────────────────────

  public getFolderUrl(fileDirRef: string): string {
    if (!fileDirRef) return "";
    // fileDirRef is server-relative e.g. /sites/mysite/ProductDocs/Brand A/2024
    return `${this.siteOrigin}${fileDirRef}`;
  }

  // ─── List all Document Libraries ──────────────────────────────────────────

  public async getAllDocumentLibraries(): Promise<ILibraryInfo[]> {
    try {
      const url =
        `${this.siteUrl}/_api/web/lists` +
        `?$filter=BaseType eq 1 and Hidden eq false and IsCatalog eq false` +
        `&$select=Id,Title,ItemCount,LastItemModifiedDate,DefaultViewUrl,Description` +
        `&$orderby=Title asc`;
      const response = await this.context.spHttpClient.get(
        url, SPHttpClient.configurations.v1, { headers: HEADERS }
      );
      if (!response.ok) throw new Error(`HTTP ${response.status}`);
      const data = await response.json();
      return (data?.d?.results || []).map((lib: any): ILibraryInfo => ({
        id:             lib.Id,
        title:          lib.Title,
        itemCount:      lib.ItemCount || 0,
        lastModified:   lib.LastItemModifiedDate,
        defaultViewUrl: lib.DefaultViewUrl || "",
        description:    lib.Description   || ""
      }));
    } catch (e) {
      console.error("[Service] getAllDocumentLibraries:", e);
      throw e;
    }
  }

  // ─── Search Items — CAML RecursiveAll ─────────────────────────────────────

  public async searchItems(
    libraryTitle: string,
    searchText: string,
    brandFilter: string
  ): Promise<IDocumentItem[]> {
    const fields = await this._discoverFields(libraryTitle);

    const allFields = [
      ...BUILTIN_FIELDS,
      ...(fields.productNo   ? [fields.productNo]   : []),
      ...(fields.brandNo     ? [fields.brandNo]     : []),
      ...(fields.description ? [fields.description] : [])
    ];

    const viewFields  = allFields.map(f => `<FieldRef Name="${f}"/>`).join("");
    const whereClause = this._buildWhereClause(searchText, brandFilter, fields);

    const camlQuery = `
      <View Scope="RecursiveAll">
        <ViewFields>${viewFields}</ViewFields>
        <Query>
          <OrderBy><FieldRef Name="Modified" Ascending="FALSE"/></OrderBy>
          ${whereClause ? `<Where>${whereClause}</Where>` : ""}
        </Query>
        <RowLimit Paged="TRUE">500</RowLimit>
      </View>`;

    const apiUrl =
      `${this.siteUrl}/_api/web/lists/getByTitle('${encodeURIComponent(libraryTitle)}')/getItems`;

    const body = JSON.stringify({
      query: { __metadata: { type: "SP.CamlQuery" }, ViewXml: camlQuery }
    });

    const response = await this.context.spHttpClient.post(
      apiUrl, SPHttpClient.configurations.v1, { headers: HEADERS, body }
    );

    if (!response.ok) {
      const err = await response.text();
      throw new Error(`Search failed (HTTP ${response.status}): ${err}`);
    }

    const data     = await response.json();
    const rawItems = data?.d?.results || [];

    return rawItems
      .map((item: any) => this._mapItem(item, libraryTitle, fields))
      .filter((item: IDocumentItem) => item.fileName !== "" || item.isDocumentSet);
  }

  // ─── Load children of a Document Set ──────────────────────────────────────

  public async getDocumentSetChildren(
    libraryTitle: string,
    documentSetServerRelativeUrl: string
  ): Promise<IDocumentItem[]> {
    try {
      const fields = await this._discoverFields(libraryTitle);
      const allFields = [
        ...BUILTIN_FIELDS,
        ...(fields.productNo   ? [fields.productNo]   : []),
        ...(fields.brandNo     ? [fields.brandNo]     : []),
        ...(fields.description ? [fields.description] : [])
      ];
      const viewFields = allFields.map(f => `<FieldRef Name="${f}"/>`).join("");

      // Use FolderServerRelativeUrl to scope query to this Document Set folder
      const camlQuery = `
        <View Scope="RecursiveAll">
          <ViewFields>${viewFields}</ViewFields>
          <Query>
            <OrderBy><FieldRef Name="FileLeafRef" Ascending="TRUE"/></OrderBy>
          </Query>
          <RowLimit>200</RowLimit>
        </View>`;

      const apiUrl =
        `${this.siteUrl}/_api/web/lists/getByTitle('${encodeURIComponent(libraryTitle)}')/getItems`;

      const body = JSON.stringify({
        query: {
          __metadata: { type: "SP.CamlQuery" },
          ViewXml: camlQuery,
          FolderServerRelativeUrl: documentSetServerRelativeUrl
        }
      });

      const response = await this.context.spHttpClient.post(
        apiUrl, SPHttpClient.configurations.v1, { headers: HEADERS, body }
      );

      if (!response.ok) return [];
      const data = await response.json();
      return (data?.d?.results || [])
        .map((item: any) => this._mapItem(item, libraryTitle, fields))
        .filter((item: IDocumentItem) => !item.isDocumentSet && item.fileName !== "");
    } catch (e) {
      console.error("[Service] getDocumentSetChildren:", e);
      return [];
    }
  }

  // ─── Brand options ─────────────────────────────────────────────────────────

  public async getBrandOptions(libraryTitle: string): Promise<string[]> {
    const fields = await this._discoverFields(libraryTitle);
    if (!fields.brandNo) return [];
    try {
      const url =
        `${this.siteUrl}/_api/web/lists/getByTitle('${encodeURIComponent(libraryTitle)}')` +
        `/fields/getByInternalNameOrTitle('${fields.brandNo}')?$select=Choices,FieldTypeKind`;
      const resp = await this.context.spHttpClient.get(
        url, SPHttpClient.configurations.v1, { headers: HEADERS }
      );
      if (resp.ok) {
        const d       = await resp.json();
        const choices = d?.d?.Choices?.results || d?.d?.Choices || [];
        if (choices.length > 0) return choices;
      }
    } catch { /* fall through */ }
    try {
      const url =
        `${this.siteUrl}/_api/web/lists/getByTitle('${encodeURIComponent(libraryTitle)}')` +
        `/items?$select=${fields.brandNo}&$top=200`;
      const resp = await this.context.spHttpClient.get(
        url, SPHttpClient.configurations.v1, { headers: HEADERS }
      );
      if (!resp.ok) return [];
      const d     = await resp.json();
      const items = d?.d?.results || [];
      const all   = items.map((i: any) => i[fields.brandNo]).filter((b: any) => b && b.toString().trim());
      return all.reduce((acc: string[], val: string) => {
        if (acc.indexOf(val) === -1) acc.push(val);
        return acc;
      }, []).sort();
    } catch { return []; }
  }

  // ─── Map raw SP item → IDocumentItem ──────────────────────────────────────

  private _mapItem(item: any, libraryTitle: string, fields: { [key: string]: string }): IDocumentItem {
    const fileLeafRef      = item["FileLeafRef"] || "";
    const fileDirRef       = item["FileDirRef"]  || "";
    const serverRelUrl     = item["FileRef"]     || "";
    const htmlFileType     = (item["HTML_x0020_File_x0020_Type"] || "").toLowerCase();
    const contentType      = item["ContentType"] || "";

    // Document Set detection: FSObjType=1 (folder) AND content type contains "Document Set"
    const isFolder         = item["FSObjType"] === 1 || item["FSObjType"] === "1";
    const isDocumentSet    = isFolder && (
      contentType.toLowerCase().indexOf("document set") !== -1 ||
      htmlFileType.indexOf("sharepoint.documentset") !== -1
    );

    const folderPath       = this._extractFolderPath(fileDirRef, libraryTitle);
    const folderName       = fileDirRef.split("/").pop() || "";
    const folderUrl        = this.getFolderUrl(fileDirRef);
    const fileExt          = fileLeafRef.split(".").pop()?.toLowerCase() || "";
    const thumbnailUrl     = isFolder ? "" : this.getThumbnailUrl(serverRelUrl, fileExt);

    // Document Set welcome page URL
    const documentSetUrl   = isDocumentSet
      ? `${this.siteOrigin}${serverRelUrl}/Forms/default.aspx`
      : "";

    const getTitle = (f: any): string => {
      if (!f) return "";
      if (typeof f === "string") return f;
      if (f.Title) return f.Title;
      if (f.results && f.results[0]) return f.results[0].Title || "";
      return "";
    };

    return {
      id:                item["ID"] || item["Id"] || 0,
      title:             item["Title"]             || "",
      name:              item["Title"]             || fileLeafRef || "(No Name)",
      productNo:         fields.productNo   ? (item[fields.productNo]   || "") : "",
      brandNo:           fields.brandNo     ? (item[fields.brandNo]     || "") : "",
      description:       fields.description ? (item[fields.description] || "") : "",
      fileName:          fileLeafRef,
      folderName,
      folderPath,
      folderUrl,                                      // ← folder link
      fileRef:           serverRelUrl ? `${this.siteOrigin}${serverRelUrl}` : "",
      serverRelativeUrl: serverRelUrl,
      libraryTitle,
      created:           item["Created"]           || "",
      modified:          item["Modified"]          || "",
      modifiedBy:        getTitle(item["Editor"]),
      fileSize:          item["File_x0020_Size"]   || 0,
      isFolder,
      isDocumentSet,                                  // ← document set flag
      documentSetUrl,                                 // ← document set link
      contentType,
      thumbnailUrl                                    // ← thumbnail
    };
  }

  // ─── CAML Where ───────────────────────────────────────────────────────────

  private _buildWhereClause(
    searchText: string,
    brandFilter: string,
    fields: { [key: string]: string }
  ): string {
    const conditions: string[] = [];
    if (searchText && searchText.trim()) {
      const q       = this._escapeXml(searchText.trim());
      const clauses = [
        `<Contains><FieldRef Name="FileLeafRef"/><Value Type="Text">${q}</Value></Contains>`,
        `<Contains><FieldRef Name="Title"/><Value Type="Text">${q}</Value></Contains>`
      ];
      if (fields.productNo)   clauses.push(`<Contains><FieldRef Name="${fields.productNo}"/><Value Type="Text">${q}</Value></Contains>`);
      if (fields.brandNo)     clauses.push(`<Contains><FieldRef Name="${fields.brandNo}"/><Value Type="Text">${q}</Value></Contains>`);
      if (fields.description) clauses.push(`<Contains><FieldRef Name="${fields.description}"/><Value Type="Text">${q}</Value></Contains>`);
      conditions.push(clauses.reduce((acc, c) => acc ? `<Or>${acc}${c}</Or>` : c));
    }
    if (brandFilter && brandFilter !== "All" && fields.brandNo) {
      conditions.push(`<Eq><FieldRef Name="${fields.brandNo}"/><Value Type="Text">${this._escapeXml(brandFilter)}</Value></Eq>`);
    }
    if (conditions.length === 0) return "";
    if (conditions.length === 1) return conditions[0];
    return `<And>${conditions[0]}${conditions[1]}</And>`;
  }

  private _extractFolderPath(fileDirRef: string, libraryTitle: string): string {
    if (!fileDirRef) return "";
    const parts    = fileDirRef.split("/");
    const libIndex = parts.findIndex(
      p => p.toLowerCase() === libraryTitle.toLowerCase() ||
           decodeURIComponent(p).toLowerCase() === libraryTitle.toLowerCase()
    );
    if (libIndex === -1) return parts[parts.length - 1] || "";
    const sub = parts.slice(libIndex + 1).filter(Boolean);
    return sub.length > 0 ? sub.join(" / ") : "(Root)";
  }

  private _escapeXml(str: string): string {
    return str.replace(/&/g,"&amp;").replace(/</g,"&lt;").replace(/>/g,"&gt;")
              .replace(/"/g,"&quot;").replace(/'/g,"&apos;");
  }
}
